<?php
function load_theme_assets() {
    // CSS Load
    wp_enqueue_style('dashboard-css', get_template_directory_uri() . '/style.css');
    
    // Firebase SDK Load
    wp_enqueue_script('firebase-app', 'https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js', array(), null, true);
    wp_enqueue_script('firebase-firestore', 'https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore-compat.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'load_theme_assets');

// 1. Inject wp_ajax global variable safely
add_action('wp_head', function() {
    echo '<script type="text/javascript">
        var wp_ajax = {
            "ajax_url": "' . esc_url(admin_url('admin-ajax.php')) . '",
            "nonce": "' . wp_create_nonce('ajax-file-nonce') . '"
        };
    </script>';
});

// 2. Handle the file upload via WordPress AJAX
add_action('wp_ajax_upload_delivery_file', 'handle_ajax_file_upload');
add_action('wp_ajax_nopriv_upload_delivery_file', 'handle_ajax_file_upload');

function handle_ajax_file_upload() {
    check_ajax_referer('ajax-file-nonce', 'security');

    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $uploadedfile = $_FILES['file'];
    $upload_overrides = array('test_form' => false);
    $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

    if ($movefile && !isset($movefile['error'])) {
        wp_send_json_success(array('url' => $movefile['url']));
    } else {
        wp_send_json_error(array('message' => $movefile['error']));
    }
}

// 3. প্রফেশনাল লগআউট সেশন ডেস্ট্রয় ও রিডাইরেক্ট হুক
add_action('wp_logout', 'professional_logout_redirect');
function professional_logout_redirect() {
    wp_clear_auth_cookie(); // সমস্ত অথেনটিকেশন কুকি ক্লিয়ার করা
    wp_redirect( home_url('/') ); // মেইন হোমপেজে বা লগইন পেজে পাঠানো
    exit();
}

// 4. ব্রাউজার ব্যাক-বাটন ও ক্যাশ মেমোরি সিকিউরিটি (No-Cache Security Filter)
add_action('wp_headers', 'prevent_dashboard_browser_caching');
function prevent_dashboard_browser_caching($headers) {
    if ( is_page_template('page-admin.php') || is_page_template('page-user.php') ) {
        $headers['Cache-Control'] = 'no-cache, must-revalidate, max-age=0, no-store, private';
        $headers['Pragma'] = 'no-cache';
        $headers['Expires'] = 'Vary';
    }
    return $headers;
}
