<?php
/**
 * Template Name: Admin Dashboard
 */

// ১. কঠোর নিরাপত্তা চেক (লগইন করা না থাকলে বা অ্যাডমিন না হলে সরাসরি ব্লক)
if ( ! is_user_logged_in() ) {
    wp_redirect( home_url('/') ); 
    exit;
} elseif ( ! current_user_can('manage_options') ) {
    // শুধুমাত্র অ্যাডমিনরাই এই পেজটি দেখতে পারবে
    wp_redirect( home_url('/user-dashboard') ); 
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — E Online Service BD</title>
<link href="https://fonts.cdnfonts.com/css/solaimanlipi" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<?php wp_head(); ?>

<style>
  :root {
    --bg-dark: #0f172a; --sidebar-bg: #1e293b; --card-bg: #1e293b; --card-light: #273449;
    --primary: #2563a8; --accent: #f97316; --success: #16a34a; --danger: #dc2626; --warning: #d97706; --info: #06b6d4;
    --text-main: #e2e8f0; --text-muted: #94a3b8; --border-color: #334155;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  
  body { font-family: 'Times New Roman', 'SolaimanLipi', serif; background: var(--bg-dark); color: var(--text-main); display: flex; min-height: 100vh; overflow-x: hidden; font-size: 15px; }
  
  .sidebar { width: 240px; background: var(--sidebar-bg); border-right: 1px solid var(--border-color); display: flex; flex-direction: column; position: fixed; height: 100vh; z-index: 100; transition: transform 0.3s ease; }
  .brand { padding: 15px; font-size: 1.1rem; font-weight: 700; color: var(--accent); border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 8px; }

  .menu-list { list-style: none; padding: 20px 0; display: flex; flex-direction: column; gap: 2px; overflow-y: auto;}
  .menu-item { padding: 10px 15px; cursor: pointer; display: flex; align-items: center; gap: 10px; color: var(--text-muted); font-weight: 500; transition: 0.2s; font-size: 0.95rem; }
  .menu-item:hover, .menu-item.active { background: rgba(255,255,255,0.05); color: var(--text-main); }
  .menu-item.active { border-left: 3px solid var(--accent); color: var(--accent); }

  .sidebar-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 90; }
  .sidebar-overlay.active { display: block; }

  .main-content { flex: 1; padding: 15px; min-width: 0; transition: margin-left 0.3s; width: 100%; display: flex; flex-direction: column; }
  .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color); }
  .header-left { display: flex; align-items: center; gap: 10px; }
  .menu-toggle { display: none; font-size: 1.2rem; cursor: pointer; color: var(--accent); background: none; border: none; }
  .page-title { font-size: 1.3rem; font-weight: 700; text-transform: uppercase; }
  
  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 15px; }
  .stat-card { background: var(--card-bg); border-radius: 8px; padding: 12px; border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: center; text-align: center; gap: 10px; min-width: 0; }
  .stat-info { display: flex; flex-direction: column; width: 100%; }
  .stat-value { font-size: 1.4rem; font-weight: 700; font-family: sans-serif; color: var(--accent); }
  .stat-label { font-size: 0.8rem; color: var(--text-muted); }

  .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 15px; width: 100%; }
  .chart-box { background: var(--card-bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color); display: flex; flex-direction: column; align-items: center; width: 100%; min-width: 0; overflow: hidden; }
  .chart-box h4 { margin-bottom: 10px; color: var(--text-muted); text-align: center; font-size: 0.9rem; }
  .chart-container { position: relative; width: 100%; height: 180px; display: flex; justify-content: center; align-items: center; }

  .panel-section { display: none; flex: 1; }
  .panel-section.active { display: block; animation: fadeIn 0.3s; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
  .data-box { background: var(--card-bg); border-radius: 8px; border: 1px solid var(--border-color); overflow: hidden; margin-bottom: 15px; padding: 15px; }
  
  .form-group { display: flex; flex-direction: column; gap: 4px; margin-bottom: 12px;}
  .form-group label { font-size: 0.9rem; font-weight: 600; color: var(--text-muted); }
  .form-group input, .form-group textarea, .form-group select { padding: 10px; background: var(--card-light); border: 1px solid var(--border-color); border-radius: 6px; color: #fff; font-family: inherit; font-size: 0.95rem; width: 100%;}

  .filter-tools { display: flex; flex-wrap: wrap; gap: 10px; background: var(--card-light); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color); margin-bottom: 15px; align-items: center; }
  .filter-search { flex: 1; min-width: 200px; position: relative; }
  .filter-search input { width: 100%; padding: 8px 10px 8px 32px; background: var(--bg-dark); border: 1px solid var(--border-color); border-radius: 6px; color: #fff; font-size: 0.9rem; }
  .filter-search i { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--text-muted); }
  .filter-select { width: 150px; padding: 8px; background: var(--bg-dark); border: 1px solid var(--border-color); border-radius: 6px; color: #fff; font-size: 0.9rem; }

  .table-responsive { width: 100%; overflow-x: auto; background: var(--card-bg); border-radius: 8px; }
  table { width: 100%; border-collapse: collapse; text-align: left; }
  th { background: var(--card-light); color: var(--text-muted); font-size: 0.85rem; padding: 12px 10px; white-space: nowrap; }
  td { padding: 12px 10px; border-bottom: 1px solid var(--border-color); font-size: 0.9rem; vertical-align: middle; }
  
  .btn { padding: 8px 15px; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; font-family: inherit; font-size: 0.95rem; display: inline-flex; align-items: center; justify-content: center; gap: 6px; color: #fff; transition: 0.2s; }
  .btn:hover { opacity: 0.8; }
  .btn-primary { background: var(--primary); }
  .btn-success { background: var(--success); }
  .btn-danger { background: var(--danger); }
  .btn-warning { background: var(--warning); }
  .btn-sm { padding: 4px 8px; font-size: 0.8rem; border-radius: 3px; }
  
  .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; display: inline-block; font-family: sans-serif;}
  .bg-p { background: rgba(217,119,6,0.15); color: #fbbf24; }
  .bg-a { background: rgba(37,99,235,0.15); color: #60a5fa; }
  .bg-d { background: rgba(22,163,74,0.15); color: #4ade80; }
  .bg-c { background: rgba(220,38,38,0.15); color: #f87171; }

  .notice-banner { background: #311c11; border: 1px solid #7c2d12; color: #fdba74; padding: 8px; border-radius: 6px; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; overflow: hidden; }
  .notice-banner span { font-weight: bold; background: var(--accent); color:#fff; padding: 2px 6px; border-radius: 4px; font-size: 0.8rem; white-space: nowrap;}
  .notice-scroll-container { flex: 1; overflow: hidden; position: relative; height: 20px; display: flex; align-items: center; }
  .notice-scroll-text { display: inline-block; white-space: nowrap; animation: scrollLeft 120s linear infinite; font-size: 0.95rem; padding-left: 100%;}
  @keyframes scrollLeft { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }

  .footer { text-align: center; padding: 15px; margin-top: auto; color: var(--text-muted); font-size: 0.9rem; border-top: 1px solid var(--border-color); }

  .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); display: none; align-items: center; justify-content: center; z-index: 999; }
  .modal-overlay.open { display: flex; }
  .modal-box { background: var(--card-bg); border: 1px solid var(--border-color); width: 100%; max-width: 500px; border-radius: 8px; padding: 20px; max-height: 90vh; overflow-y: auto;}

  /* Firebase Login Overlay */
  #adminLogin { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: var(--bg-dark); width:100vw; position:fixed; z-index:9999; top:0; left:0;}

  @media(min-width: 769px) { .sidebar { transform: translateX(0) !important; } .main-content { margin-left: 240px; } }
  @media(max-width: 768px) { 
    .sidebar { transform: translateX(-100%); } .sidebar.open { transform: translateX(0); } .menu-toggle { display: block; } .main-content { margin-left: 0; } 
    .stats-grid { grid-template-columns: repeat(3, 1fr); gap: 6px; }
    .stat-card { padding: 8px 4px; text-align: center; gap: 5px; flex-direction: column;}
    .stat-value { font-size: 1rem; }
    .stat-label { font-size: 0.65rem; line-height: 1.1; }
    .charts-grid { grid-template-columns: 1fr; gap: 10px; }
    .chart-container { height: 150px; }
  }

  @media print {
    @page { size: A4 portrait; margin: 1cm; }
    html, body { height: auto !important; min-height: auto !important; overflow: visible !important; background: #fff !important; margin: 0 !important; padding: 0 !important; color: #000 !important; font-family: 'Times New Roman', serif; }
    #adminLogin, .sidebar, .top-bar, .notice-banner, .stats-grid, .charts-grid, .modal-overlay, .sidebar-overlay, #wpadminbar, .filter-tools, .footer { display: none !important; }
    .main-content { margin: 0 !important; padding: 0 !important; min-height: auto !important; height: auto !important;}
    .panel-section { display: none !important; }
    #printVoucherArea { display: block !important; width: 100% !important; margin: 0 !important; padding: 0 !important; padding-bottom: 60px !important; page-break-inside: avoid !important; position: relative !important; }
    #printVoucherArea::before { content: ""; position: fixed !important; top: 50% !important; left: 50% !important; transform: translate(-50%, -50%) !important; width: 400px !important; height: 400px !important; background-image: url('https://eonlineservicebd.kesug.com/wp-content/uploads/2026/06/E-Online-Service-BD-Logo.png') !important; background-repeat: no-repeat !important; background-position: center !important; background-size: contain !important; opacity: 0.2 !important; pointer-events: none !important; z-index: 1 !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    table { page-break-inside: auto; width: 100% !important; border-collapse: collapse; }
    tr { page-break-inside: avoid; page-break-after: auto; }
    thead { display: table-header-group; }
    .print-footer { position: fixed !important; bottom: 0 !important; left: 0 !important; width: 100% !important; border-top: 1px solid #ccc !important; padding-top: 5px !important; display: flex !important; justify-content: center !important; font-style: italic !important; color: grey !important; font-size: 11px !important; background: transparent !important; page-break-inside: avoid !important; page-break-after: avoid !important; z-index: 10 !important; }
  }
</style>
</head>
<body>

<div id="adminLogin">
  <div style="background: var(--card-bg); border-radius: 12px; padding: 25px; width: 90%; max-width: 350px; border: 1px solid var(--border-color);">
    <h2 style="color:var(--accent); text-align:center; margin-bottom:15px; font-family: 'Times New Roman', serif;"><i class="fa-solid fa-lock"></i> Admin Login</h2>
    <div class="form-group"><label>Email Address</label><input type="email" id="adminEmail"></div>
    <div class="form-group" style="margin-bottom:15px"><label>Password</label><input type="password" id="adminPass"></div>
    <button class="btn btn-primary" style="width:100%; justify-content:center" id="loginBtn">Secure Login</button>
  </div>
</div>

<div class="modal-overlay" id="editCustomerModal">
  <div class="modal-box">
    <h3><i class="fa-solid fa-user-gear"></i> Edit Customer</h3>
    <input type="hidden" id="editCustomerId">
    <div class="form-group"><label>Full Name</label><input type="text" id="editCustomerName"></div>
    <div class="form-group"><label>Mobile Number</label><input type="text" id="editCustomerMobile"></div>
    <div class="form-group"><label>WhatsApp Number</label><input type="text" id="editCustomerWhatsApp"></div>
    <div class="form-group"><label>Balance (৳)</label><input type="number" id="editCustomerBalance"></div>
    <div class="form-group">
      <label>Status</label>
      <select id="editCustomerStatus">
        <option value="Pending">Pending</option>
        <option value="Approved">Approved</option>
        <option value="suspended">Suspended</option>
      </select>
    </div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-danger" onclick="closeEditCustomerModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveCustomerChange()">Save Changes</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="addCategoryModal">
  <div class="modal-box">
    <h3><i class="fa-solid fa-plus"></i> Add New Category</h3>
    <div class="form-group"><label>Category Name</label><input type="text" id="newCatName" placeholder="e.g. Passport Service"></div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-danger" onclick="closeAddCategoryModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveCategory()">Save</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="serviceModal">
  <div class="modal-box">
    <h3 id="serviceModalTitle"><i class="fa-solid fa-plus"></i> Add Service</h3>
    <input type="hidden" id="serviceId">
    <div class="form-group"><label>Service Name</label><input type="text" id="serName"></div>
    <div class="form-group"><label>Category</label><select id="serCategory"></select></div>
    <div class="form-group"><label>Price (৳)</label><input type="number" id="serPrice" placeholder="0"></div>
    <div class="form-group"><label>Form Requirements (Comma Separated)</label><input type="text" id="serRequirements" placeholder="e.g. Full Name, NID Number, Date of Birth"></div>
    <div class="form-group">
       <label>File Upload Option</label>
       <select id="serFileNeeded">
          <option value="false">Not Needed</option>
          <option value="true">Required (Mandatory)</option>
       </select>
    </div>
    <div class="form-group"><label>File Upload Instruction Note</label><input type="text" id="serFileInstruction" placeholder="e.g. Upload your NID scanned copy PDF"></div>
    <div class="form-group">
      <label>Status</label>
      <select id="serEnabled">
         <option value="true">Active/Enabled</option>
         <option value="false">Disabled</option>
      </select>
    </div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-danger" onclick="closeServiceModal()">Cancel</button>
      <button class="btn btn-primary" id="saveServiceBtn" onclick="saveService()">Save Service</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="deliveryModal">
  <div class="modal-box">
    <h3><i class="fa-solid fa-truck-ramp-box"></i> Deliver / Complete Order</h3>
    <input type="hidden" id="deliveryOrderId">
    <div class="form-group"><label>Delivery Text Note / Information</label><textarea id="deliveryNote" rows="3" placeholder="Enter download links or text information here..."></textarea></div>
    <div class="form-group"><label>Upload Delivery File (Optional)</label><input type="file" id="deliveryFile"></div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-danger" onclick="closeDeliveryModal()">Cancel</button>
      <button class="btn btn-success" id="confirmDeliveryBtn" onclick="submitDelivery()">Complete Delivery</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="rejectOrderModal">
  <div class="modal-box">
    <h3><i class="fa-solid fa-ban"></i> Cancel/Reject Order</h3>
    <input type="hidden" id="rejectOrderId">
    <div class="form-group"><label>Reason for Cancellation</label><textarea id="rejectReason" rows="3" placeholder="Why are you canceling this order? (User will see this)"></textarea></div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-primary" onclick="closeRejectOrderModal()">Back</button>
      <button class="btn btn-danger" onclick="submitOrderRejection()">Confirm Cancel</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="ticketAnsModal">
  <div class="modal-box">
    <h3><i class="fa-solid fa-reply"></i> Support Ticket Reply & Close</h3>
    <input type="hidden" id="ansTicketId">
    <div class="form-group"><label>Your Answer / Resolution Note</label><textarea id="ticketAnswerText" rows="4" placeholder="Type your message to user..."></textarea></div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-danger" onclick="closeTicketAnsModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitTicketAnswer()">Send & Close</button>
    </div>
  </div>
</div>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
<div class="sidebar" id="sidebar">
  <div class="brand"><i class="fa-solid fa-bolt"></i> <span>Admin Panel</span></div>
  <ul class="menu-list">
    <li class="menu-item active" onclick="switchTab('dashboard')"><i class="fa-solid fa-chart-line"></i> Dashboard</li>
    <li class="menu-item" onclick="switchTab('profile')"><i class="fa-solid fa-user-circle"></i> My Profile</li>
    <li class="menu-item" onclick="switchTab('customers')"><i class="fa-solid fa-users"></i> Customers</li>
    <li class="menu-item" onclick="switchTab('categories')"><i class="fa-solid fa-tags"></i> Categories</li>
    <li class="menu-item" onclick="switchTab('all-services')"><i class="fa-solid fa-briefcase"></i> Services</li>
    <li class="menu-item" onclick="switchTab('orders')"><i class="fa-solid fa-cart-shopping"></i> Manage Orders</li>
    <li class="menu-item" onclick="switchTab('payments')"><i class="fa-solid fa-money-bill-wave"></i> Deposits</li>
    <li class="menu-item" onclick="switchTab('tickets')"><i class="fa-solid fa-headset"></i> Tickets</li>
    <li class="menu-item" onclick="switchTab('settings')"><i class="fa-solid fa-sliders"></i> Web Settings</li>
    <li class="menu-item" onclick="switchTab('reports')"><i class="fa-solid fa-file-excel"></i> Export Reports</li>
  </ul>
</div>

<div class="main-content">
  <div id="printVoucherArea" style="display:none; font-family: 'Times New Roman', serif;"></div>

  <div class="top-bar">
    <div class="header-left">
      <button class="menu-toggle" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></button>
      <div class="page-title" id="pageTitle">Dashboard</div>
    </div>
    <div class="header-right" style="display:flex; align-items:center;">
      <div class="notification-wrapper" style="position:relative; display:inline-block; margin-right:15px;">
         <button class="notification-icon" onclick="toggleNotificationDropdown(event)" style="background:none; border:none; color:var(--text-main); font-size:1.4rem; cursor:pointer; position:relative;">
            <i class="fa-solid fa-bell"></i>
            <span id="notifBadge" style="display:none; position:absolute; top:-4px; right:-6px; background:var(--danger); color:#fff; font-size:0.65rem; font-weight:bold; padding:2px 5px; border-radius:50%;">0</span>
         </button>
         
         <div id="notification-dropdown" style="display:none; position:absolute; right:0; top:45px; width:300px; background:var(--card-bg); border:1px solid var(--border-color); border-radius:8px; box-shadow:0 8px 16px rgba(0,0,0,0.5); z-index:9999; overflow:hidden;">
            <div style="padding:12px 15px; background:var(--card-light); border-bottom:1px solid var(--border-color); display:flex; justify-content:space-between; align-items:center; font-weight:bold; font-size:0.9rem; color:var(--text-main);">
                <span>Notifications</span>
                <button onclick="markAllRead(event)" style="background:none; border:none; color:var(--info); font-size:0.8rem; cursor:pointer;">Mark all read</button>
            </div>
            <div id="notifList" style="max-height:350px; overflow-y:auto;"></div>
         </div>
      </div>
      </div>
  </div>

  <div class="notice-banner">
    <span>NOTICE</span>
    <div class="notice-scroll-container">
       <div id="liveNoticeView" class="notice-scroll-text">Loading...</div>
    </div>
  </div>

  <div id="tab-dashboard" class="panel-section active">
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="s-tot-user">0</span><span class="stat-label">Total Users</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="s-pen-user" style="color:var(--warning);">0</span><span class="stat-label">Pending Users</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="s-tot-ord">0</span><span class="stat-label">Total Orders</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="s-pen-ord" style="color:var(--warning);">0</span><span class="stat-label">Pending Orders</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="s-pen-dep" style="color:var(--info);">0</span><span class="stat-label">Pending Deposits</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="s-open-tic" style="color:var(--danger);">0</span><span class="stat-label">Open Tickets</span></div></div>
    </div>
    <div class="charts-grid">
       <div class="chart-box"><h4>Global Orders Performance</h4><div class="chart-container"><canvas id="admColChart"></canvas></div></div>
       <div class="chart-box"><h4>Revenue Flow Timeline</h4><div class="chart-container"><canvas id="admLineChart"></canvas></div></div>
    </div>
  </div>

  <div id="tab-profile" class="panel-section">
      <div class="data-box" style="max-width: 500px; margin: 0 auto; padding: 0; overflow: hidden; border: 1px solid var(--border-color); border-radius: 12px; background: var(--card-bg);">
          <div style="background: linear-gradient(135deg, var(--primary), var(--bg-dark)); padding: 40px 20px; text-align: center; border-bottom: 3px solid var(--accent);">
              <?php 
                $admin_user = wp_get_current_user();
                $admin_display_name = $admin_user->display_name;
                $admin_user_email = $admin_user->user_email;
              ?>
              <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($admin_display_name); ?>&background=f97316&color=fff&size=128" style="width:110px; height:110px; border-radius:50%; margin-bottom: 15px; border: 4px solid var(--bg-dark); box-shadow: 0 4px 10px rgba(0,0,0,0.5);">
              <h3 style="font-size: 1.4rem; color: #fff; margin-bottom: 5px; font-weight: bold;"><?php echo esc_html($admin_display_name); ?></h3>
              <p style="color:#cbd5e1; font-size: 0.95rem;"><i class="fa-solid fa-envelope"></i> <?php echo esc_html($admin_user_email); ?></p>
          </div>
          <div style="padding: 25px 20px;">
              <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed var(--border-color); padding-bottom: 12px; margin-bottom: 12px;">
                  <span style="color:var(--text-muted); font-weight: 600;"><i class="fa-solid fa-shield-halved"></i> Account Role</span>
                  <span class="badge bg-a" style="font-size: 13px; padding: 5px 12px;">Administrator</span>
              </div>
              <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed var(--border-color); padding-bottom: 12px; margin-bottom: 25px;">
                  <span style="color:var(--text-muted); font-weight: 600;"><i class="fa-solid fa-circle-check"></i> Account Status</span>
                  <span class="badge bg-d" style="font-size: 13px; padding: 5px 12px;">Active</span>
              </div>
              <button class="btn btn-danger" onclick="triggerAdminLogout()" style="width:100%; justify-content:center; padding: 12px; font-size: 1rem;"><i class="fa-solid fa-right-from-bracket"></i> Clear Session & Logout</button>
          </div>
      </div>
  </div>

  <div id="tab-customers" class="panel-section">
    <div class="data-box">
      <h3><i class="fa-solid fa-users"></i> Customer Management</h3>
      <div class="table-responsive" style="margin-top:15px;">
        <table>
          <thead>
            <tr>
              <th>Photo</th>
              <th>UID / Custom ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>WhatsApp</th>
              <th>Balance</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="adminCustomersTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="tab-categories" class="panel-section">
    <div class="data-box">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
         <h3><i class="fa-solid fa-tags"></i> Service Categories</h3>
         <button class="btn btn-primary" onclick="openAddCategoryModal()"><i class="fa-solid fa-plus"></i> New Category</button>
      </div>
      <div class="table-responsive">
        <table>
          <thead><tr><th>Category Name</th><th>Actions</th></tr></thead>
          <tbody id="adminCategoriesTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="tab-all-services" class="panel-section">
    <div class="data-box">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
         <h3><i class="fa-solid fa-briefcase"></i> Service List</h3>
         <button class="btn btn-primary" onclick="openServiceModal(false)"><i class="fa-solid fa-plus"></i> Add Service</button>
      </div>
      
      <div class="filter-tools">
         <div class="filter-search">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="serviceSearchInput" placeholder="Search by service name..." oninput="filterServicesEngine()">
         </div>
         <select class="filter-select" id="serviceCatFilter" onchange="filterServicesEngine()">
            <option value="All">All Categories</option>
         </select>
      </div>

      <div class="table-responsive">
         <table>
           <thead><tr><th>Service Name</th><th>Category</th><th>Price</th><th>Req Fields</th><th>File Option</th><th>Status</th><th>Actions</th></tr></thead>
           <tbody id="adminServicesTable"></tbody>
         </table>
      </div>
    </div>
  </div>

  <div id="tab-orders" class="panel-section">
    <div class="data-box">
      <h3><i class="fa-solid fa-cart-shopping"></i> Global Orders Panel</h3>
      
      <div class="filter-tools" style="margin-top:15px;">
         <div class="filter-search">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="orderSearchInput" placeholder="Search by UID, Order ID, or Task Name..." oninput="filterOrdersEngine()">
         </div>
         <select class="filter-select" id="orderStatusFilter" onchange="filterOrdersEngine()">
            <option value="All">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Success">Success</option>
            <option value="Cancel">Cancel</option>
         </select>
         <input type="date" class="filter-select" id="orderDateFilter" onchange="filterOrdersEngine()" style="width:160px;">
         <button class="btn btn-danger btn-sm" onclick="resetOrderFilters()"><i class="fa-solid fa-rotate"></i> Reset</button>
      </div>

      <div class="table-responsive" style="margin-top:15px;">
        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>User Email</th>
              <th>Service</th>
              <th>Price</th>
              <th>User Provided Form Requirements Data</th>
              <th>User File</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="adminOrdersTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="tab-payments" class="panel-section">
    <div class="data-box">
      <h3><i class="fa-solid fa-money-bill-wave"></i> Deposit Balance Requests</h3>
      <div class="table-responsive" style="margin-top:15px;">
        <table>
          <thead><tr><th>User Email</th><th>Method</th><th>TrxID</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody id="adminPaymentsTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="tab-tickets" class="panel-section">
    <div class="data-box">
      <h3><i class="fa-solid fa-headset"></i> User Tickets</h3>
      <div class="table-responsive" style="margin-top:15px;">
         <table>
           <thead><tr><th>User Email</th><th>Subject</th><th>Message</th><th>Admin Answer</th><th>Status</th><th>Action</th></tr></thead>
           <tbody id="adminTicketsTable"></tbody>
         </table>
      </div>
    </div>
  </div>

  <div id="tab-settings" class="panel-section">
    <div class="data-box" style="max-width:600px;">
       <h3><i class="fa-solid fa-sliders"></i> Notice & Marquee Configuration</h3>
       <div class="form-group" style="margin-top:15px;"><label>Live Scroll Scrolling Notice Text</label><textarea id="setNoticeText" rows="3"></textarea></div>
       <button class="btn btn-success" onclick="saveGlobalNotice()">Update Notice</button>
    </div>
    
    <div class="data-box" style="max-width:600px;">
       <h3><i class="fa-solid fa-phone"></i> Contacts Configuration</h3>
       <div class="form-group"><label>WhatsApp Direct Link</label><input type="text" id="setContactWhatsApp"></div>
       <div class="form-group"><label>Telegram Direct Link</label><input type="text" id="setContactTelegram"></div>
       <button class="btn btn-success" onclick="saveContactConfig()">Update Contacts</button>
    </div>

    <div class="data-box" style="max-width:600px;">
       <h3><i class="fa-solid fa-building-columns"></i> Payment Gateway Numbers</h3>
       
       <h4 style="margin:10px 0; color:var(--info);">bKash Gateway</h4>
       <div class="form-group"><label>bKash Number</label><input type="text" id="p-bkash-num"></div>
       <div class="form-group"><label>bKash Type</label><input type="text" id="p-bkash-ty" placeholder="Personal / Agent / Merchant"></div>
       <div class="form-group"><label>bKash Status</label><select id="p-bkash-st"><option value="true">Active</option><option value="false">Inactive</option></select></div>
       
       <h4 style="margin:15px 0 10px 0; color:var(--info);">Nagad Gateway</h4>
       <div class="form-group"><label>Nagad Number</label><input type="text" id="p-nagad-num"></div>
       <div class="form-group"><label>Nagad Type</label><input type="text" id="p-nagad-ty" placeholder="Personal / Agent / Merchant"></div>
       <div class="form-group"><label>Nagad Status</label><select id="p-nagad-st"><option value="true">Active</option><option value="false">Inactive</option></select></div>
       
       <h4 style="margin:15px 0 10px 0; color:var(--info);">Rocket Gateway</h4>
       <div class="form-group"><label>Rocket Number</label><input type="text" id="p-rocket-num"></div>
       <div class="form-group"><label>Rocket Type</label><input type="text" id="p-rocket-ty" placeholder="Personal / Agent / Merchant"></div>
       <div class="form-group"><label>Rocket Status</label><select id="p-rocket-st"><option value="true">Active</option><option value="false">Inactive</option></select></div>

       <button class="btn btn-success" style="margin-top:15px; width:100%;" onclick="savePaymentConfig()">Update Gateways Configuration</button>
    </div>
  </div>

  <div id="tab-reports" class="panel-section">
     <div class="data-box" style="max-width:500px;">
        <h3><i class="fa-solid fa-file-excel"></i> Export Systems Financial Reports</h3>
        <div class="form-group" style="margin-top:15px;"><label>Select Category</label><select id="reportCategory"><option value="">-- Choose Category --</option><option value="customers">Customers database</option><option value="categories">Categories list</option><option value="all_services">Services list</option><option value="orders">Orders logs</option><option value="payments">Deposits logs</option><option value="tickets">Support tickets</option></select></div>
        <div class="form-group"><label>Start Date (Optional)</label><input type="date" id="reportStartDate"></div>
        <div class="form-group"><label>End Date (Optional)</label><input type="date" id="reportEndDate"></div>
        <button class="btn btn-primary" style="width:100%; margin-top:10px;" onclick="generateExcelReport()"><i class="fa-solid fa-download"></i> Generate Excel File</button>
        <button class="btn btn-success" style="width:100%; margin-top:10px;" onclick="printDynamicReport()"><i class="fa-solid fa-print"></i> Print Report</button>
     </div>
  </div>

  <footer class="footer">Copyright @ 2026 | E Online Service BD</footer>
</div>

<script type="module">
  // Firebase Auth Features Added
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
  import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
  import { getFirestore, doc, setDoc, getDoc, collection, onSnapshot, updateDoc, deleteDoc, runTransaction, query, where, addDoc } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

  const firebaseConfig = {
    apiKey: "AIzaSyADPFsjyqo0zUXzXFzCQ40YbUQDKW5qd2o",
    authDomain: "e-online-service.firebaseapp.com",
    projectId: "e-online-service",
    storageBucket: "e-online-service.firebasestorage.app",
    messagingSenderId: "557870086410",
    appId: "1:557870086410:web:926155d23b0ff67fb222f3"
  };

  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);
  const db = getFirestore(app);

  let allUsersArray = [];
  let pendingUsersArray = []; // To handle Pending Users Collection 
  let allCategoriesArray = [];
  let allServicesArray = [];
  let allOrders = [];
  let allPaymentsArray = [];
  let allTicketsArray = [];
  let adminNotifsArray = [];

  let admColChartInst = null;
  let admLineChartInst = null;

  function formatToCustomDate(dateStr) {
      if(!dateStr) return 'N/A';
      const d = new Date(dateStr);
      if(isNaN(d)) return dateStr.split(' ')[0];
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const day = String(d.getDate()).padStart(2, '0');
      const year = d.getFullYear();
      return `${day} ${months[d.getMonth()]} ${year}`;
  }

  // --- Auth & Session Logic ---
  onAuthStateChanged(auth, (user) => {
    if (user) {
      document.getElementById('adminLogin').style.display = 'none';
      initCoreSystemData();
    } else {
      document.getElementById('adminLogin').style.display = 'flex';
    }
  });

  document.getElementById('loginBtn').addEventListener('click', async () => {
    const email = document.getElementById('adminEmail').value.trim();
    const pass = document.getElementById('adminPass').value.trim();
    if(!email || !pass) return alert('Please enter all info!');
    try { await signInWithEmailAndPassword(auth, email, pass); } catch(e) { alert(e.message); }
  });

  window.triggerAdminLogout = async function() {
      if(confirm("আপনি কি নিশ্চিতভাবে অ্যাডমিন প্যানেল থেকে লগআউট করতে চান?")) {
          await signOut(auth);
          window.location.href = "<?php echo wp_logout_url(home_url('/')); ?>"; 
      }
  };

  window.toggleSidebar = function() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
  };

  window.switchTab = function(id) {
      document.querySelectorAll('.panel-section').forEach(el => el.classList.remove('active'));
      document.getElementById('tab-' + id).classList.add('active');
      document.getElementById('pageTitle').textContent = id.toUpperCase().replace('-', ' ');
      document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
      event.currentTarget.classList.add('active');
      if(window.innerWidth <= 768) toggleSidebar();
  };

  function initAdminNotifications() {
      const qNotif = query(collection(db, "notifications"), where("target", "==", "admin"));
      onSnapshot(qNotif, (snap) => {
          adminNotifsArray = []; let unread = 0;
          snap.forEach(d => { let n = {id: d.id, ...d.data()}; adminNotifsArray.push(n); if(!n.isRead) unread++; });
          adminNotifsArray.sort((a,b) => b.timestamp - a.timestamp);

          const badge = document.getElementById('notifBadge');
          if(unread > 0) { badge.textContent = unread; badge.style.display = 'block'; } else { badge.style.display = 'none'; }

          const list = document.getElementById('notifList'); list.innerHTML = '';
          if(adminNotifsArray.length === 0) {
              list.innerHTML = '<div style="padding:20px; text-align:center; color:var(--text-muted); font-size:0.85rem;">No notifications yet.</div>';
          } else {
              adminNotifsArray.forEach((n, index) => {
                  let time = formatToCustomDate(n.date) + ' ' + new Date(n.timestamp).toLocaleTimeString();
                  let bg = n.isRead ? 'transparent' : 'rgba(37,99,235,0.1)';
                  list.innerHTML += `<div onclick="readNotif('${n.id}')" style="padding:12px 15px; border-bottom:1px solid var(--border-color); font-size:0.85rem; color:var(--text-main); display:flex; gap:8px; cursor:pointer; background:${bg};">
                      <span style="color:var(--accent); font-weight:bold; font-size:0.9rem;">${index + 1}.</span>
                      <div style="flex:1; line-height:1.4;">
                          <div style="font-weight:bold;">${n.title}</div>
                          <div>${n.message}</div>
                          <span style="display:block; font-size:0.7rem; color:var(--info); margin-top:4px;">${time}</span>
                      </div>
                  </div>`;
              });
          }
      });
  }

  window.toggleNotificationDropdown = function(event) { 
      event.stopPropagation(); 
      const dropdown = document.getElementById('notification-dropdown');
      dropdown.style.display = (dropdown.style.display === 'none' || dropdown.style.display === '') ? 'block' : 'none';
  };
  window.readNotif = async function(id) { await updateDoc(doc(db, "notifications", id), { isRead: true }); document.getElementById('notification-dropdown').style.display = 'none'; };
  window.markAllRead = function(event) { event.stopPropagation(); adminNotifsArray.forEach(async (n) => { if(!n.isRead) await updateDoc(doc(db, "notifications", n.id), { isRead: true }); }); };
  
  window.addEventListener('click', function(event) { 
      const wrapper = document.querySelector('.notification-wrapper');
      const dropdown = document.getElementById('notification-dropdown');
      if (dropdown && dropdown.style.display === 'block' && (!wrapper || !wrapper.contains(event.target))) { 
          dropdown.style.display = 'none'; 
      }
  });

  // --- Core Data Initialization ---
  function initCoreSystemData() {
      initAdminNotifications();

      // Fetch pending_users Collection from page-admin.php
      onSnapshot(collection(db, "pending_users"), (snap) => {
          pendingUsersArray = [];
          snap.forEach(d => { pendingUsersArray.push({ id: d.id, isPendingCol: true, status: 'Pending', role: 'User', ...d.data() }); });
          mergeAndRenderCustomers();
      });

      onSnapshot(collection(db, "users"), (snap) => {
          allUsersArray = [];
          snap.forEach(d => { allUsersArray.push({ id: d.id, isPendingCol: false, ...d.data() }); });
          mergeAndRenderCustomers();
      });

      onSnapshot(collection(db, "categories"), (snap) => {
          allCategoriesArray = [];
          snap.forEach(d => { allCategoriesArray.push({ id: d.id, ...d.data() }); });
          renderCategories();
          updateServiceModalCategoriesDropdown();
      });

      onSnapshot(collection(db, "services"), (snap) => {
          allServicesArray = [];
          snap.forEach(d => { allServicesArray.push({ id: d.id, ...d.data() }); });
          renderServices(allServicesArray);
      });

      onSnapshot(collection(db, "orders"), (snap) => {
          allOrders = [];
          snap.forEach(d => { allOrders.push({ id: d.id, ...d.data() }); });
          renderOrders(allOrders); 
          calculateDashboardStats();
      });

      onSnapshot(collection(db, "deposits"), (snap) => {
          allPaymentsArray = [];
          snap.forEach(d => { allPaymentsArray.push({ id: d.id, ...d.data() }); });
          renderPayments();
          calculateDashboardStats();
      });

      onSnapshot(collection(db, "tickets"), (snap) => {
          allTicketsArray = [];
          snap.forEach(d => { allTicketsArray.push({ id: d.id, ...d.data() }); });
          renderTickets();
          calculateDashboardStats();
      });

      onSnapshot(doc(db, "settings", "global"), (snap) => {
          if(snap.exists()) {
              const text = snap.data().notice || "";
              document.getElementById('setNoticeText').value = text;
              const spacer = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
              const continuousText = text ? `${text} ${spacer} ${text} ${spacer} ${text} ${spacer} ${text}` : 'No active notice.';
              document.getElementById('liveNoticeView').innerHTML = continuousText;
          }
      });
      
      onSnapshot(doc(db, "settings", "contact_config"), (snap) => {
          if(snap.exists()) {
              document.getElementById('setContactWhatsApp').value = snap.data().whatsapp || '';
              document.getElementById('setContactTelegram').value = snap.data().telegram || '';
          }
      });
      
      onSnapshot(doc(db, "settings", "payment_config"), (snap) => {
          if(snap.exists()) {
              const d = snap.data();
              if(d.bkash) { document.getElementById('p-bkash-num').value = d.bkash.number || ''; document.getElementById('p-bkash-ty').value = d.bkash.type || ''; document.getElementById('p-bkash-st').value = String(d.bkash.status); }
              if(d.nagad) { document.getElementById('p-nagad-num').value = d.nagad.number || ''; document.getElementById('p-nagad-ty').value = d.nagad.type || ''; document.getElementById('p-nagad-st').value = String(d.nagad.status); }
              if(d.rocket) { document.getElementById('p-rocket-num').value = d.rocket.number || ''; document.getElementById('p-rocket-ty').value = d.rocket.type || ''; document.getElementById('p-rocket-st').value = String(d.rocket.status); }
          }
      });
  }

  function mergeAndRenderCustomers() {
      let combined = [...pendingUsersArray, ...allUsersArray];
      renderCustomers(combined);
      calculateDashboardStats();
  }

  function calculateDashboardStats() {
      let totalU = allUsersArray.length + pendingUsersArray.length;
      document.getElementById('s-tot-user').textContent = totalU;
      document.getElementById('s-pen-user').textContent = pendingUsersArray.length + allUsersArray.filter(u => u.status === 'Pending').length;
      document.getElementById('s-tot-ord').textContent = allOrders.length;
      document.getElementById('s-pen-ord').textContent = allOrders.filter(o => o.status === 'Pending').length;
      document.getElementById('s-pen-dep').textContent = allPaymentsArray.filter(p => p.status === 'Pending').length;
      document.getElementById('s-open-tic').textContent = allTicketsArray.filter(t => t.status === 'Open').length;

      let penO = allOrders.filter(o => o.status === 'Pending').length;
      let sucO = allOrders.filter(o => o.status === 'Success').length;
      let canO = allOrders.filter(o => o.status === 'Cancel').length;

      let timelineData = {};
      allOrders.forEach(o => {
          if (o.status === 'Success') {
              let d = o.date ? o.date.split(' ')[0] : 'N/A';
              timelineData[d] = (timelineData[d] || 0) + Number(o.price);
          }
      });

      Chart.defaults.color = '#94a3b8';
      Chart.defaults.font.family = "'Times New Roman', serif";

      const ctxCol = document.getElementById('admColChart');
      if(ctxCol) {
          if(admColChartInst) admColChartInst.destroy();
          admColChartInst = new Chart(ctxCol, {
              type: 'bar',
              data: { labels: ['Pending', 'Success', 'Canceled'], datasets: [{ data: [penO, sucO, canO], backgroundColor: ['#d97706', '#16a34a', '#dc2626'], borderRadius: 4 }] },
              options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
          });
      }

      const ctxLine = document.getElementById('admLineChart');
      if(ctxLine) {
          if(admLineChartInst) admLineChartInst.destroy();
          let sortedDates = Object.keys(timelineData).sort((a,b) => new Date(a) - new Date(b));
          let revValues = sortedDates.map(dt => timelineData[dt]);
          admLineChartInst = new Chart(ctxLine, {
              type: 'line',
              data: { labels: sortedDates.length ? sortedDates : ['N/A'], datasets: [{ label: 'Revenue Flow (৳)', data: revValues.length ? revValues : [0], borderColor: '#f97316', backgroundColor: 'rgba(249,115,22,0.1)', fill: true, tension: 0.3 }] },
              options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
          });
      }
  }

  function renderCustomers(dataArray) {
      const cont = document.getElementById('adminCustomersTable'); if(!cont) return;
      cont.innerHTML = '';
      dataArray.forEach(u => {
          let pPhoto = u.photoUrl && u.photoUrl !== "" ? u.photoUrl : "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
          cont.innerHTML += `<tr>
             <td><img src="${pPhoto}" style="width:35px; height:35px; border-radius:50%; object-fit:cover; border:1px solid var(--border-color);"></td>
             <td><small style="color:var(--text-muted); font-family:monospace;">${u.customId || u.id}</small></td>
             <td><b>${u.name || 'N/A'}</b></td>
             <td><small>${u.email}</small></td>
             <td>${u.mobile || '-'}</td>
             <td>${u.whatsapp || '-'}</td>
             <td><b>৳${u.balance || 0}</b></td>
             <td><span class="badge ${u.status==='Pending'?'bg-p':(u.status==='Approved'||u.status==='Active'?'bg-d':'bg-c')}">${u.status}</span></td>
             <td>
                <div style="display:flex; flex-wrap:wrap; gap:4px;">
                   <button class="btn btn-warning btn-sm" title="Add Balance" onclick="adjustUserBalance('${u.id}', ${u.isPendingCol})"><i class="fa-solid fa-plus"></i> Bal</button>
                   
                   <button class="btn btn-primary btn-sm" onclick="openEditCustomerModal('${u.id}', '${encodeURIComponent(u.name||'')}', '${u.mobile||''}', '${u.whatsapp||''}', ${u.balance||0}, '${u.status}', ${u.isPendingCol})"><i class="fa-solid fa-pen"></i></button>
                   ${u.status==='Pending'?`<button class="btn btn-success btn-sm" onclick="approveCustomer('${u.id}', ${u.isPendingCol})"><i class="fa-solid fa-check"></i> Approve</button>`:''}
                   <button class="btn btn-danger btn-sm" onclick="deleteCustomer('${u.id}', ${u.isPendingCol})"><i class="fa-solid fa-trash"></i></button>
                </div>
             </td>
          </tr>`;
      });
  }

  // Quick Balance Adjustment
  window.adjustUserBalance = async function(uid, isPending) {
     if(isPending) return alert("Cannot add balance to pending user! Approve them first.");
     const amt = prompt("Amount to add? (৳)"); if(!amt || isNaN(amt)) return;
     await runTransaction(db, async (trans) => {
        const sfDoc = await trans.get(doc(db, "users", uid));
        trans.update(doc(db, "users", uid), { balance: (sfDoc.data().balance || 0) + Number(amt) });
     });
     alert('Balance added successfully!');
  };

  // Modified Approve to handle Pending Collection logic 
  window.approveCustomer = async function(id, isPendingCol) {
      if(!confirm("Are you sure to approve this customer?")) return;
      try {
          const cid = "usr_" + Math.floor(10000 + Math.random() * 90000);
          
          if(isPendingCol) {
             const pendingRef = doc(db, "pending_users", id);
             const pendingSnap = await getDoc(pendingRef);
             if (pendingSnap.exists()) {
                 const userData = pendingSnap.data();
                 await setDoc(doc(db, "users", id), { ...userData, customId: cid, status: 'Active', balance: 0 });
                 await deleteDoc(pendingRef);
             }
          } else {
             await updateDoc(doc(db, "users", id), { status: 'Active', customId: cid });
          }

          await addDoc(collection(db, "notifications"), {
              target: 'user', userId: id, title: 'Account Activated Successfully!', message: `Congratulations! Your account is approved. Your assigned User ID is: ${cid}`, isRead: false, timestamp: Date.now(), date: new Date().toISOString()
          });
          
          alert("Customer approved successfully!");
      } catch(e) { alert(e.message); }
  };

  window.openEditCustomerModal = function(id, nameEnc, mobile, whatsapp, bal, status, isPending) {
      document.getElementById('editCustomerId').value = id + '|||' + isPending;
      document.getElementById('editCustomerName').value = decodeURIComponent(nameEnc);
      document.getElementById('editCustomerMobile').value = mobile;
      document.getElementById('editCustomerWhatsApp').value = whatsapp;
      document.getElementById('editCustomerBalance').value = bal;
      document.getElementById('editCustomerStatus').value = status;
      document.getElementById('editCustomerModal').classList.add('open');
  };
  window.closeEditCustomerModal = function() { document.getElementById('editCustomerModal').classList.remove('open'); };
  window.saveCustomerChange = async function() {
      const parts = document.getElementById('editCustomerId').value.split('|||');
      const id = parts[0]; const isPending = parts[1] === 'true';
      
      const n = document.getElementById('editCustomerName').value;
      const m = document.getElementById('editCustomerMobile').value;
      const w = document.getElementById('editCustomerWhatsApp').value;
      const b = Number(document.getElementById('editCustomerBalance').value);
      const s = document.getElementById('editCustomerStatus').value;

      try {
          const collectionName = isPending ? "pending_users" : "users";
          await updateDoc(doc(db, collectionName, id), { name: n, mobile: m, whatsapp: w, balance: b, status: s });
          alert("Changes saved!"); closeEditCustomerModal();
      } catch(e) { alert(e.message); }
  };
  window.deleteCustomer = async function(id, isPending) {
      if(confirm("Permanently delete this customer document from database?")) {
          const collectionName = isPending ? "pending_users" : "users";
          await deleteDoc(doc(db, collectionName, id));
      }
  };

  function renderCategories() {
      const cont = document.getElementById('adminCategoriesTable'); if(!cont) return;
      cont.innerHTML = '';
      allCategoriesArray.forEach(c => {
          cont.innerHTML += `<tr>
             <td><b>${c.name}</b></td>
             <td><button class="btn btn-danger btn-sm" onclick="deleteCategory('${c.id}')"><i class="fa-solid fa-trash"></i> Delete</button></td>
          </tr>`;
      });
  }
  window.openAddCategoryModal = function() { document.getElementById('addCategoryModal').classList.add('open'); };
  window.closeAddCategoryModal = function() { document.getElementById('addCategoryModal').classList.remove('open'); };
  window.saveCategory = async function() {
      const nm = document.getElementById('newCatName').value.trim();
      if(!nm) return;
      await setDoc(doc(db, "categories", "cat_" + Date.now()), { name: nm });
      document.getElementById('newCatName').value = ''; closeAddCategoryModal();
  };
  window.deleteCategory = async function(id) { if(confirm("Delete category?")) await deleteDoc(doc(db, "categories", id)); };

  function updateServiceModalCategoriesDropdown() {
      const d = document.getElementById('serCategory'); 
      const filter = document.getElementById('serviceCatFilter');
      if(d) d.innerHTML = '';
      if(filter) filter.innerHTML = '<option value="All">All Categories</option>';
      allCategoriesArray.forEach(c => { 
          if(d) d.innerHTML += `<option value="${c.name}">${c.name}</option>`; 
          if(filter) filter.innerHTML += `<option value="${c.name}">${c.name}</option>`;
      });
  }

  // Service Filtering Engine Added
  window.filterServicesEngine = function() {
     const searchVal = document.getElementById('serviceSearchInput').value.toLowerCase().trim();
     const catVal = document.getElementById('serviceCatFilter').value;
     let filtered = allServicesArray.filter(s => {
        let matchSearch = !searchVal || s.name.toLowerCase().includes(searchVal);
        let matchCat = catVal === 'All' || s.category === catVal;
        return matchSearch && matchCat;
     });
     renderServices(filtered);
  }

  function renderServices(dataArray) {
      const cont = document.getElementById('adminServicesTable'); if(!cont) return;
      cont.innerHTML = '';
      dataArray.forEach(s => {
          let reqs = s.requirements ? s.requirements.join(', ') : '-';
          cont.innerHTML += `<tr>
             <td><b>${s.name}</b></td>
             <td>${s.category}</td>
             <td><b>৳${s.price}</b></td>
             <td><small style="color:var(--text-muted);">${reqs}</small></td>
             <td><small>${s.fileNeeded==='true'||s.fileNeeded===true?'Mandatory':'None'} ${s.fileInstruction?`(${s.fileInstruction})`:''}</small></td>
             <td><span class="badge ${s.enabled===true||s.enabled==='true'?'bg-d':'bg-c'}">${s.enabled===true||s.enabled==='true'?'Active':'Disabled'}</span></td>
             <td>
                <div style="display:flex; gap:4px;">
                   <button class="btn btn-primary btn-sm" onclick="openServiceModal(true, '${s.id}', '${encodeURIComponent(s.name)}', '${s.category}', ${s.price}, '${encodeURIComponent(reqs)}', ${s.fileNeeded}, '${encodeURIComponent(s.fileInstruction||'')}', ${s.enabled})"><i class="fa-solid fa-pen"></i></button>
                   <button class="btn btn-danger btn-sm" onclick="deleteService('${s.id}')"><i class="fa-solid fa-trash"></i></button>
                </div>
             </td>
          </tr>`;
      });
  }

  window.openServiceModal = function(isEdit, id, nameEnc, cat, price, reqsEnc, fileNeeded, fileInsEnc, enabled) {
      updateServiceModalCategoriesDropdown();
      if(isEdit) {
          document.getElementById('serviceModalTitle').innerHTML = '<i class="fa-solid fa-pen"></i> Edit Service';
          document.getElementById('serviceId').value = id;
          document.getElementById('serName').value = decodeURIComponent(nameEnc);
          document.getElementById('serCategory').value = cat;
          document.getElementById('serPrice').value = price;
          document.getElementById('serRequirements').value = decodeURIComponent(reqsEnc);
          document.getElementById('serFileNeeded').value = String(fileNeeded);
          document.getElementById('serFileInstruction').value = decodeURIComponent(fileInsEnc);
          document.getElementById('serEnabled').value = String(enabled);
      } else {
          document.getElementById('serviceModalTitle').innerHTML = '<i class="fa-solid fa-plus"></i> Add Service';
          document.getElementById('serviceId').value = '';
          document.getElementById('serName').value = '';
          document.getElementById('serPrice').value = '';
          document.getElementById('serRequirements').value = '';
          document.getElementById('serFileNeeded').value = 'false';
          document.getElementById('serFileInstruction').value = '';
          document.getElementById('serEnabled').value = 'true';
      }
      document.getElementById('serviceModal').classList.add('open');
  };
  window.closeServiceModal = function() { document.getElementById('serviceModal').classList.remove('open'); };
  window.saveService = async function() {
      const id = document.getElementById('serviceId').value;
      const nm = document.getElementById('serName').value.trim();
      const ct = document.getElementById('serCategory').value;
      const pr = Number(document.getElementById('serPrice').value);
      const rq = document.getElementById('serRequirements').value.split(',').map(item=>item.trim()).filter(item=>item!=='');
      const fn = document.getElementById('serFileNeeded').value === 'true';
      const fi = document.getElementById('serFileInstruction').value.trim();
      const en = document.getElementById('serEnabled').value === 'true';

      if(!nm || pr < 0) return alert("Valid Name & Price required!");
      const b = document.getElementById('saveServiceBtn'); b.disabled = true;

      let docId = id ? id : "ser_" + Date.now();
      try {
          await setDoc(doc(db, "services", docId), { name: nm, category: ct, price: pr, requirements: rq, fileNeeded: fn, fileInstruction: fi, enabled: en });
          closeServiceModal();
      } catch(e){alert(e.message);} finally { b.disabled = false; }
  };
  window.deleteService = async function(id) { if(confirm("Delete service?")) await deleteDoc(doc(db, "services", id)); };

  window.filterOrdersEngine = function() {
     const searchVal = document.getElementById('orderSearchInput').value.toLowerCase().trim();
     const statusVal = document.getElementById('orderStatusFilter').value;
     const dateVal = document.getElementById('orderDateFilter').value;
     
     let filtered = allOrders.filter(o => {
        let matchesSearch = !searchVal || 
                            (o.userEmail && o.userEmail.toLowerCase().includes(searchVal)) || 
                            (o.userId && o.userId.toLowerCase().includes(searchVal)) || 
                            (o.id && o.id.toLowerCase().includes(searchVal)) || 
                            (o.workName && o.workName.toLowerCase().includes(searchVal));
        let matchesStatus = (statusVal === 'All') || (o.status === statusVal);
        let matchesDate = !dateVal || (o.date && o.date.includes(dateVal));
        return matchesSearch && matchesStatus && matchesDate;
     });
     renderOrders(filtered);
  }

  window.resetOrderFilters = function() {
     document.getElementById('orderSearchInput').value = '';
     document.getElementById('orderStatusFilter').value = 'All';
     document.getElementById('orderDateFilter').value = '';
     renderOrders(allOrders);
  }

  function renderOrders(dataArray) {
      const cont = document.getElementById('adminOrdersTable'); if(!cont) return;
      cont.innerHTML = '';
      dataArray.sort((a,b) => new Date(b.date) - new Date(a.date)).forEach(o => {
          let customDataHtml = '';
          if(o.customData) {
              for (const [key, value] of Object.entries(o.customData)) {
                  customDataHtml += `<div><b>${key}:</b> ${value}</div>`;
              }
          }
          let fLink = o.fileUrl ? `<a href="${o.fileUrl}" target="_blank" class="btn btn-primary btn-sm" style="padding:2px 6px; font-size:11px; margin-top:4px;"><i class="fa-solid fa-file-arrow-down"></i> Open File</a>` : '<span style="color:var(--text-muted); font-size:12px;">No File</span>';
          
          cont.innerHTML += `<tr>
             <td><b>${o.id}</b></td>
             <td><small>${o.userEmail}</small></td>
             <td>${o.workName}</td>
             <td><b>৳${o.price}</b></td>
             <td><div style="font-size:13px; line-height:1.4; color:var(--text-main);">${customDataHtml}</div></td>
             <td>${fLink}</td>
             <td><span class="badge ${o.status==='Pending'?'bg-p':(o.status==='Success'?'bg-d':'bg-c')}">${o.status}</span></td>
             <td>
                <div style="display:flex; flex-wrap:wrap; gap:4px;">
                   ${o.status==='Pending'?`<button class="btn btn-success btn-sm" onclick="openDeliveryModal('${o.id}')"><i class="fa-solid fa-truck"></i> Deliver</button>`:''}
                   ${o.status==='Pending'?`<button class="btn btn-danger btn-sm" onclick="openRejectOrderModal('${o.id}')"><i class="fa-solid fa-ban"></i> Cancel</button>`:''}
                   
                   <button class="btn btn-warning btn-sm" onclick="printSingleVoucher('${o.id}')"><i class="fa-solid fa-print"></i> Print</button>
                </div>
             </td>
          </tr>`;
      });
  }

  window.openDeliveryModal = function(id) { document.getElementById('deliveryOrderId').value = id; document.getElementById('deliveryNote').value = ''; document.getElementById('deliveryFile').value = ''; document.getElementById('deliveryModal').classList.add('open'); };
  window.closeDeliveryModal = function() { document.getElementById('deliveryModal').classList.remove('open'); };
  window.submitDelivery = async function() {
      const id = document.getElementById('deliveryOrderId').value;
      const note = document.getElementById('deliveryNote').value.trim();
      const fileInput = document.getElementById('deliveryFile');
      
      const btn = document.getElementById('confirmDeliveryBtn'); btn.disabled = true; btn.textContent = 'Processing...';
      let fileUrl = '';
      if(fileInput.files.length > 0) {
          if(typeof window.wp_ajax !== 'undefined') {
              let fd = new FormData(); fd.append('action', 'upload_delivery_file'); fd.append('file', fileInput.files[0]); fd.append('security', window.wp_ajax.nonce);
              try { let res = await fetch(window.wp_ajax.ajax_url, { method: 'POST', body: fd }); let json = await res.json(); if(json.success) fileUrl = json.data.url; } catch(e) { console.log(e); }
          }
      }

      try {
          const oRef = doc(db, "orders", id);
          const oSnap = await getDoc(oRef);
          await updateDoc(oRef, { status: 'Success', deliveryNote: note, deliveryFile: fileUrl });
          if(oSnap.exists()) {
              await addDoc(collection(db, "notifications"), { target: 'user', userId: oSnap.data().userId, title: 'Order Completed', message: `Your order ${id} has been delivered successfully.`, isRead: false, timestamp: Date.now(), date: new Date().toISOString() });
          }
          alert("Order Delivered Successfully!"); closeDeliveryModal();
      } catch(e) { alert(e.message); } finally { btn.disabled = false; btn.textContent = 'Complete Delivery'; }
  };

  window.openRejectOrderModal = function(id) { document.getElementById('rejectOrderId').value = id; document.getElementById('rejectReason').value = ''; document.getElementById('rejectOrderModal').classList.add('open'); };
  window.closeRejectOrderModal = function() { document.getElementById('rejectOrderModal').classList.remove('open'); };
  window.submitOrderRejection = async function() {
      const id = document.getElementById('rejectOrderId').value;
      const reason = document.getElementById('rejectReason').value.trim();
      if(!reason) return alert("Write cancellation reason!");

      try {
          await runTransaction(db, async (trans) => {
              const oRef = doc(db, "orders", id); const oSnap = await trans.get(oRef);
              if(!oSnap.exists()) throw "Order not found.";
              if(oSnap.data().status !== 'Pending') throw "Order already handled.";
              
              const uRef = doc(db, "users", oSnap.data().userId); const uSnap = await trans.get(uRef);
              let refundAmt = Number(oSnap.data().price);
              let currentBal = uSnap.exists() ? Number(uSnap.data().balance || 0) : 0;

              trans.update(oRef, { status: 'Cancel', cancelReason: reason });
              trans.update(uRef, { balance: currentBal + refundAmt });
              
              const newNotifRef = doc(collection(db, "notifications"));
              trans.set(newNotifRef, { target: 'user', userId: oSnap.data().userId, title: 'Order Rejected & Refunded', message: `Your order ${id} is canceled. Reason: ${reason}. ৳${refundAmt} refunded.`, isRead: false, timestamp: Date.now(), date: new Date().toISOString() });
          });
          alert("Order Canceled & Refunded!"); closeRejectOrderModal();
      } catch(e) { alert("Action Failed: " + e); }
  };

  function renderPayments() {
      const cont = document.getElementById('adminPaymentsTable'); if(!cont) return;
      cont.innerHTML = '';
      allPaymentsArray.sort((a,b) => new Date(b.date) - new Date(a.date)).forEach(p => {
          cont.innerHTML += `<tr>
             <td><small>${p.userEmail}</small></td>
             <td><b style="color:var(--info);">${p.method}</b></td>
             <td><span style="font-family:monospace; letter-spacing:0.5px;">${p.trxId}</span></td>
             <td><b>৳${p.amount}</b></td>
             <td><span class="badge ${p.status==='Pending'?'bg-p':(p.status==='Approved'?'bg-d':'bg-c')}">${p.status}</span></td>
             <td>
                <div style="display:flex; gap:4px;">
                   ${p.status==='Pending'?`<button class="btn btn-success btn-sm" onclick="approvePayment('${p.id}')">Approve</button>`:''}
                   ${p.status==='Pending'?`<button class="btn btn-danger btn-sm" onclick="rejectPayment('${p.id}')">Reject</button>`:''}
                   ${p.status!=='Pending'?'-':''}
                </div>
             </td>
          </tr>`;
      });
  }

  window.approvePayment = async function(id) {
      if(!confirm("Approve this deposit request & add balance to user?")) return;
      try {
          await runTransaction(db, async (trans) => {
              const pRef = doc(db, "deposits", id); const pSnap = await trans.get(pRef);
              if(!pSnap.exists()) throw "Deposit record missing.";
              if(pSnap.data().status !== 'Pending') throw "Already processed.";

              const uRef = doc(db, "users", pSnap.data().userId); const uSnap = await trans.get(uRef);
              let currentBal = uSnap.exists() ? Number(uSnap.data().balance || 0) : 0;
              let depositAmt = Number(pSnap.data().amount);

              trans.update(pRef, { status: 'Approved' });
              trans.update(uRef, { balance: currentBal + depositAmt });

              const newNotifRef = doc(collection(db, "notifications"));
              trans.set(newNotifRef, { target: 'user', userId: pSnap.data().userId, title: 'Deposit Approved', message: `Your deposit request of ৳${depositAmt} has been approved.`, isRead: false, timestamp: Date.now(), date: new Date().toISOString() });
          });
          alert("Deposit Request Approved!");
      } catch(e) { alert("Transaction Failed: " + e); }
  };

  window.rejectPayment = async function(id) {
      if(confirm("Reject this deposit request?")) {
          const pRef = doc(db, "deposits", id);
          const pSnap = await getDoc(pRef);
          await updateDoc(pRef, { status: 'Rejected' });
          if(pSnap.exists()) {
              await addDoc(collection(db, "notifications"), { target: 'user', userId: pSnap.data().userId, title: 'Deposit Rejected', message: `Your deposit request of ৳${pSnap.data().amount} was rejected.`, isRead: false, timestamp: Date.now(), date: new Date().toISOString() });
          }
      }
  };

  function renderTickets() {
      const cont = document.getElementById('adminTicketsTable'); if(!cont) return;
      cont.innerHTML = '';
      allTicketsArray.sort((a,b) => new Date(b.date) - new Date(a.date)).forEach(t => {
          cont.innerHTML += `<tr>
             <td><small>${t.userEmail}</small></td>
             <td><b>${t.subject}</b></td>
             <td><small>${t.message}</small></td>
             <td><span style="color:var(--info); font-size:13px;">${t.adminCloseNote || '-'}</span></td>
             <td><span class="badge ${t.status==='Open'?'bg-p':'bg-d'}">${t.status}</span></td>
             <td>
                ${t.status==='Open'?`<button class="btn btn-primary btn-sm" onclick="openTicketAnsModal('${t.id}')"><i class="fa-solid fa-reply"></i> Reply</button>`:'-'}
             </td>
          </tr>`;
      });
  }
  window.openTicketAnsModal = function(id) { document.getElementById('ansTicketId').value = id; document.getElementById('ticketAnswerText').value = ''; document.getElementById('ticketAnsModal').classList.add('open'); };
  window.closeTicketAnsModal = function() { document.getElementById('ticketAnsModal').classList.remove('open'); };
  window.submitTicketAnswer = async function() {
      const id = document.getElementById('ansTicketId').value;
      const ans = document.getElementById('ticketAnswerText').value.trim();
      if(!ans) return alert("Type your resolution text first!");

      const tRef = doc(db, "tickets", id);
      const tSnap = await getDoc(tRef);
      await updateDoc(tRef, { status: 'Closed', adminCloseNote: ans });
      if(tSnap.exists()) {
          await addDoc(collection(db, "notifications"), { target: 'user', userId: tSnap.data().userId, title: 'Ticket Resolved', message: `Your ticket regarding "${tSnap.data().subject}" has been answered and closed.`, isRead: false, timestamp: Date.now(), date: new Date().toISOString() });
      }
      alert("Ticket closed!"); closeTicketAnsModal();
  };

  window.saveGlobalNotice = async function() {
      const txt = document.getElementById('setNoticeText').value.trim();
      await setDoc(doc(db, "settings", "global"), { notice: txt }); alert("Notice banner updated dynamically!");
  };
  window.saveContactConfig = async function() {
      const wa = document.getElementById('setContactWhatsApp').value.trim();
      const tg = document.getElementById('setContactTelegram').value.trim();
      await setDoc(doc(db, "settings", "contact_config"), { whatsapp: wa, telegram: tg }); alert("Contacts configuration saved!");
  };
  window.savePaymentConfig = async function() {
      const bn = document.getElementById('p-bkash-num').value.trim();
      const bt = document.getElementById('p-bkash-ty').value.trim();
      const bs = document.getElementById('p-bkash-st').value === 'true';

      const nn = document.getElementById('p-nagad-num').value.trim();
      const nt = document.getElementById('p-nagad-ty').value.trim();
      const ns = document.getElementById('p-nagad-st').value === 'true';

      const rn = document.getElementById('p-rocket-num').value.trim();
      const rt = document.getElementById('p-rocket-ty').value.trim();
      const rs = document.getElementById('p-rocket-st').value === 'true';

      await setDoc(doc(db, "settings", "payment_config"), {
          bkash: { number: bn, type: bt, status: bs },
          nagad: { number: nn, type: nt, status: ns },
          rocket: { number: rn, type: rt, status: rs }
      });
      alert("All Gateways settings updated!");
  };

  window.generateExcelReport = function() {
      const category = document.getElementById('reportCategory').value;
      let rawData = []; let sheetName = ""; let fileName = "";

      if (category === 'customers') { rawData = [...pendingUsersArray, ...allUsersArray]; sheetName = "Customers"; fileName = "Customers_Report.xlsx"; } 
      else if (category === 'categories') { rawData = allCategoriesArray; sheetName = "Categories"; fileName = "Categories_Report.xlsx"; } 
      else if (category === 'all_services') { rawData = allServicesArray; sheetName = "Services"; fileName = "Services_Report.xlsx"; } 
      else if (category === 'orders') { rawData = allOrders; sheetName = "Orders"; fileName = "Orders_Report.xlsx"; } 
      else if (category === 'payments') { rawData = allPaymentsArray; sheetName = "Payments"; fileName = "Payments_Report.xlsx"; } 
      else if (category === 'tickets') { rawData = allTicketsArray; sheetName = "Tickets"; fileName = "Tickets_Report.xlsx"; } 
      else { alert('Please select a report category first!'); return; }

      const startDate = document.getElementById('reportStartDate').value;
      const endDate = document.getElementById('reportEndDate').value;
      if (startDate && endDate) {
          rawData = rawData.filter(item => {
              let d = item.date ? item.date.split(' ')[0] : '';
              return d >= startDate && d <= endDate;
          });
      }

      // Format Data with Serial Numbers and All Columns
      let dataToExport = rawData.map((item, index) => {
          let formattedItem = { "Serial No": index + 1 };
          
          if (category === 'customers') {
              formattedItem["UID"] = item.customId || item.id;
              formattedItem["Name"] = item.name || 'N/A';
              formattedItem["Email"] = item.email || 'N/A';
              formattedItem["Mobile"] = item.mobile || 'N/A';
              formattedItem["WhatsApp"] = item.whatsapp || 'N/A';
              formattedItem["Balance"] = item.balance || 0;
              formattedItem["Status"] = item.status || 'N/A';
          } else if (category === 'categories') {
              formattedItem["Category ID"] = item.id;
              formattedItem["Category Name"] = item.name;
          } else if (category === 'all_services') {
              formattedItem["Service Name"] = item.name;
              formattedItem["Category"] = item.category;
              formattedItem["Price"] = item.price;
              formattedItem["Requirements"] = item.requirements ? item.requirements.join(', ') : 'None';
              formattedItem["File Option"] = item.fileNeeded ? 'Mandatory' : 'None';
              formattedItem["Status"] = (item.enabled === true || item.enabled === 'true') ? 'Active' : 'Disabled';
          } else if (category === 'orders') {
              formattedItem["Order ID"] = item.id;
              formattedItem["Date"] = item.date ? item.date.split(' ')[0] : 'N/A';
              formattedItem["User Email"] = item.userEmail;
              formattedItem["Service Name"] = item.workName;
              formattedItem["Price"] = item.price;
              formattedItem["Status"] = item.status;
              if(item.customData) {
                  for(const [key, value] of Object.entries(item.customData)) {
                      formattedItem[`Input: ${key}`] = value;
                  }
              }
          } else if (category === 'payments') {
              formattedItem["Date"] = item.date ? item.date.split(' ')[0] : 'N/A';
              formattedItem["User"] = item.userEmail || item.userId;
              formattedItem["Method"] = item.method;
              formattedItem["Trx ID"] = item.trxId;
              formattedItem["Amount"] = item.amount;
              formattedItem["Status"] = item.status;
          } else if (category === 'tickets') {
              formattedItem["Date"] = item.date ? item.date.split(' ')[0] : 'N/A';
              formattedItem["User"] = item.userEmail;
              formattedItem["Subject"] = item.subject;
              formattedItem["Message"] = item.message;
              formattedItem["Status"] = item.status;
              formattedItem["Admin Note"] = item.adminCloseNote || '';
          }
          return formattedItem;
      });

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(dataToExport);
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
      XLSX.writeFile(wb, fileName);
  };

  window.printDynamicReport = function() {
     const category = document.getElementById('reportCategory').value;
     const startDate = document.getElementById('reportStartDate').value;
     const endDate = document.getElementById('reportEndDate').value;
     const printArea = document.getElementById('printVoucherArea');
     if(!category) return alert('Please select a report category from the dropdown!');

     let contentHTML = '', title = '';
     
     if(category === 'customers') {
        title = "Customer Control Report (All Users)";
        let rows = '';
        const combo = [...pendingUsersArray, ...allUsersArray];
        combo.forEach((u, i) => { rows += `<tr><td style="border:1px solid #000; padding:6px; text-align:center;">${i+1}</td><td style="border:1px solid #000; padding:6px;">${u.customId || u.id}</td><td style="border:1px solid #000; padding:6px;">${u.name || 'N/A'}</td><td style="border:1px solid #000; padding:6px;">${u.email}</td><td style="border:1px solid #000; padding:6px;">${u.mobile || '-'}</td><td style="border:1px solid #000; padding:6px;">${u.whatsapp || '-'}</td><td style="border:1px solid #000; padding:6px;">৳${u.balance||0}</td><td style="border:1px solid #000; padding:6px;">${u.status}</td></tr>`; });
        contentHTML = `<table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;"><tr style="background:#f2f2f2;"><th style="border:1px solid #000; padding:6px; width:40px;">SL</th><th style="border:1px solid #000; padding:6px;">UID</th><th style="border:1px solid #000; padding:6px;">Name</th><th style="border:1px solid #000; padding:6px;">Email</th><th style="border:1px solid #000; padding:6px;">Mobile</th><th style="border:1px solid #000; padding:6px;">WhatsApp</th><th style="border:1px solid #000; padding:6px;">Balance</th><th style="border:1px solid #000; padding:6px;">Status</th></tr>${rows}</table>`;
     }
     else if(category === 'categories') {
        title = "System Category List";
        let rows = ''; allCategoriesArray.forEach((c, i) => { rows += `<tr><td style="border:1px solid #000; padding:6px; text-align:center;">${i+1}</td><td style="border:1px solid #000; padding:6px;">${c.id}</td><td style="border:1px solid #000; padding:6px;">${c.name}</td></tr>`; });
        contentHTML = `<table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;"><tr style="background:#f2f2f2;"><th style="border:1px solid #000; padding:6px; width:40px;">SL</th><th style="border:1px solid #000; padding:6px;">Category ID</th><th style="border:1px solid #000; padding:6px;">Category Name</th></tr>${rows}</table>`;
     }
     else if (category === 'all_services') {
        title = "All Services List (A to Z)";
        let rowsStr = ''; allServicesArray.forEach((s, index) => { 
            let reqs = s.requirements ? s.requirements.join(', ') : 'None';
            rowsStr += `<tr><td style="border:1px solid #000; padding:6px; text-align:center;">${index+1}</td><td style="border:1px solid #000; padding:6px;">${s.name}</td><td style="border:1px solid #000; padding:6px;">${s.category}</td><td style="border:1px solid #000; padding:6px;">${reqs}</td><td style="border:1px solid #000; padding:6px;">${s.enabled===true||s.enabled==='true'?'Active':'Disabled'}</td><td style="border:1px solid #000; padding:6px; text-align:right;">৳${s.price}</td></tr>`; 
        });
        contentHTML = `<table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;"><tr style="background:#f2f2f2;"><th style="border:1px solid #000; padding:6px; width:40px;">SL</th><th style="border:1px solid #000; padding:6px;">Service Name</th><th style="border:1px solid #000; padding:6px;">Category</th><th style="border:1px solid #000; padding:6px;">Requirements</th><th style="border:1px solid #000; padding:6px;">Status</th><th style="border:1px solid #000; padding:6px; text-align:right;">Price</th></tr>${rowsStr}</table>`;
     }
     else if (category === 'orders') {
        let filtered = allOrders;
        if(startDate && endDate) { filtered = filtered.filter(o => { let d = o.date ? o.date.split(' ')[0] : ''; return d >= startDate && d <= endDate; }); title = `Order Report (${startDate} to ${endDate})`; } else { title = 'Total Order List Report'; }
        let rowsStr = '', grandTotal = 0;
        filtered.forEach((o, index) => { 
            if(o.status === 'Success') grandTotal += o.price; 
            rowsStr += `<tr><td style="border:1px solid #000; padding:6px; text-align:center;">${index+1}</td><td style="border:1px solid #000; padding:6px;">${o.id}</td><td style="border:1px solid #000; padding:6px;">${o.userEmail}</td><td style="border:1px solid #000; padding:6px; white-space:nowrap;">${formatToCustomDate(o.date)}</td><td style="border:1px solid #000; padding:6px;">${o.workName}</td><td style="border:1px solid #000; padding:6px;">${o.status}</td><td style="border:1px solid #000; padding:6px; text-align:right;">৳${o.price}</td></tr>`; 
        });
        contentHTML = `<table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;"><tr style="background:#f2f2f2;"><th style="border:1px solid #000; padding:6px; width:40px;">SL</th><th style="border:1px solid #000; padding:6px;">Order ID</th><th style="border:1px solid #000; padding:6px;">User Email</th><th style="border:1px solid #000; padding:6px;">Date</th><th style="border:1px solid #000; padding:6px;">Service Name</th><th style="border:1px solid #000; padding:6px;">Status</th><th style="border:1px solid #000; padding:6px; text-align:right;">Amount</th></tr>${rowsStr}</table><h3 style="text-align:right; margin-top:10px;">Total Income (Success): ৳${grandTotal}</h3>`;
     }
     else if(category === 'payments') {
        let filtered = allPaymentsArray;
        if(startDate && endDate) { filtered = filtered.filter(p => { let d = p.date ? p.date.split(' ')[0] : ''; return d >= startDate && d <= endDate; }); }
        title = "Recharge & Payments Report"; let rows = '';
        filtered.forEach((p, i) => { rows += `<tr><td style="border:1px solid #000; padding:6px; text-align:center;">${i+1}</td><td style="border:1px solid #000; padding:6px; white-space:nowrap;">${formatToCustomDate(p.date)}</td><td style="border:1px solid #000; padding:6px;">${p.userEmail || p.userId}</td><td style="border:1px solid #000; padding:6px;">${p.trxId}</td><td style="border:1px solid #000; padding:6px;">৳${p.amount}</td><td style="border:1px solid #000; padding:6px;">${p.status}</td></tr>`; });
        contentHTML = `<table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;"><tr style="background:#f2f2f2;"><th style="border:1px solid #000; padding:6px; width:40px;">SL</th><th style="border:1px solid #000; padding:6px;">Date</th><th style="border:1px solid #000; padding:6px;">User</th><th style="border:1px solid #000; padding:6px;">Trx ID</th><th style="border:1px solid #000; padding:6px;">Amount</th><th style="border:1px solid #000; padding:6px;">Status</th></tr>${rows}</table>`;
     }
     else if(category === 'tickets') {
        title = "Support Ticket Report"; let rows = '';
        allTicketsArray.forEach((t, i) => { rows += `<tr><td style="border:1px solid #000; padding:6px; text-align:center;">${i+1}</td><td style="border:1px solid #000; padding:6px; white-space:nowrap;">${formatToCustomDate(t.date)}</td><td style="border:1px solid #000; padding:6px;">${t.userEmail}</td><td style="border:1px solid #000; padding:6px;">${t.subject}</td><td style="border:1px solid #000; padding:6px;">${t.message}</td><td style="border:1px solid #000; padding:6px;">${t.status}</td></tr>`; });
        contentHTML = `<table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;"><tr style="background:#f2f2f2;"><th style="border:1px solid #000; padding:6px; width:40px;">SL</th><th style="border:1px solid #000; padding:6px;">Date</th><th style="border:1px solid #000; padding:6px;">User Email</th><th style="border:1px solid #000; padding:6px;">Subject</th><th style="border:1px solid #000; padding:6px;">Message</th><th style="border:1px solid #000; padding:6px;">Status</th></tr>${rows}</table>`;
     }

     printArea.innerHTML = `
        <div style="padding:10px; font-family: 'Times New Roman', serif;">
           <h2 style="text-align:center; margin-bottom:5px; border-bottom:2px solid #000; padding-bottom:10px;">E ONLINE SERVICE BD</h2>
           <h3 style="text-align:center; margin-top:10px; margin-bottom:20px;">${title}</h3>
           ${contentHTML}
        </div>
        <div class="print-footer">
            This is a system-generated document. No signature or seal is required. | &copy; 2026 E Online Service BD.
        </div>
     `;
     window.print();
  }

  window.printSingleVoucher = function(orderId) {
     const order = allOrders.find(o => o.id === orderId);
     if(!order) return alert('Order not found!');
     
     const printArea = document.getElementById('printVoucherArea');
     printArea.innerHTML = `
        <div style="border: 2px dashed #000; padding: 20px; max-width: 500px; margin: 0 auto; line-height: 1.6; font-family: 'Times New Roman', serif;">
           <h2 style="text-align:center; margin-bottom: 2px;">E ONLINE SERVICE BD</h2>
           <p style="text-align:center; font-size:12px; margin:0 0 15px 0;">Order Money Receipt / Customer Voucher</p>
           <hr style="border-top:1px dashed #000;">
           <p><b>Order ID:</b> ${order.id}</p>
           <p><b>Customer Email:</b> ${order.userEmail || 'N/A'}</p>
           <p><b>Date & Time:</b> ${formatToCustomDate(order.date)}</p>
           <p><b>Service Name:</b> ${order.workName}</p>
           <p><b>Payment Status:</b> ${order.status}</p>
           <hr style="border-top:1px dashed #000;">
           <h3 style="display:flex; justify-content:space-between; margin-top:10px;"><span>Total Bill:</span> <span>৳${order.price}</span></h3>
           <hr style="border-top:1px dashed #000;">
           <p style="margin-top:20px; font-size:11px; text-align:center;">Thank you for using our service!</p>
        </div>
        <div class="print-footer">
            This is a system-generated document. No signature or seal is required. | &copy; 2026 E Online Service BD.
        </div>
     `;
     window.print();
  }
</script>

<?php wp_footer(); ?>
</body>
</html>
