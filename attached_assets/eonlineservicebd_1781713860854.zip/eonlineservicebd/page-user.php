<?php
/**
 * Template Name: User Dashboard
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Dashboard — E Online Service BD</title>
<link href="https://fonts.cdnfonts.com/css/solaimanlipi" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php wp_head(); ?>

<style>
  :root {
    --bg-dark: #0f172a; --sidebar-bg: #1e293b; --card-bg: #1e293b; --card-light: #273449;
    --primary: #2563a8; --accent: #f97316; --success: #16a34a; --danger: #dc2626; --warning: #d97706; --info: #06b6d4;
    --text-main: #e2e8f0; --text-muted: #94a3b8; --border-color: #334155;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  
  body { font-family: 'Times New Roman', 'SolaimanLipi', serif; background: var(--bg-dark); color: var(--text-main); display: flex; min-height: 100vh; overflow-x: hidden; font-size: 15px; }
  
  .sidebar { width: 240px; background: var(--sidebar-bg); border-right: 1px solid var(--border-color); display: flex; flex-direction: column; position: fixed; height: 100vh; z-index: 100; transition: transform 0.3s ease; }
  .brand { padding: 15px; font-size: 1.1rem; font-weight: 700; color: var(--accent); border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 8px; }

  .menu-list { list-style: none; padding: 20px 0; display: flex; flex-direction: column; gap: 2px; overflow-y: auto;}
  .menu-item { padding: 10px 15px; cursor: pointer; display: flex; align-items: center; gap: 10px; color: var(--text-muted); font-weight: 500; transition: 0.2s; font-size: 0.95rem; }
  .menu-item:hover, .menu-item.active { background: rgba(255,255,255,0.05); color: var(--text-main); }
  .menu-item.active { border-left: 3px solid var(--accent); color: var(--accent); }

  .sidebar-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 90; }
  .sidebar-overlay.active { display: block; }

  .main-content { flex: 1; padding: 15px; min-width: 0; transition: margin-left 0.3s; width: 100%; display: flex; flex-direction: column; }
  .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color); }
  .header-left { display: flex; align-items: center; gap: 10px; }
  .menu-toggle { display: none; font-size: 1.2rem; cursor: pointer; color: var(--accent); background: none; border: none; }
  .page-title { font-size: 1.3rem; font-weight: 700; text-transform: uppercase; }
  .user-bal-badge { background: rgba(22,163,74,0.15); color: #4ade80; padding: 6px 12px; border-radius: 6px; font-weight: bold; font-family: sans-serif; border: 1px solid #16a34a; }
  
  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 15px; }
  .stat-card { background: var(--card-bg); border-radius: 8px; padding: 12px; border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: center; text-align: center; gap: 10px; min-width: 0; }
  .stat-info { display: flex; flex-direction: column; width: 100%; }
  .stat-value { font-size: 1.4rem; font-weight: 700; font-family: sans-serif; color: var(--accent); }
  .stat-label { font-size: 0.8rem; color: var(--text-muted); }

  .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 15px; width: 100%; }
  .chart-box { background: var(--card-bg); padding: 15px; border-radius: 8px; border: 1px solid var(--border-color); display: flex; flex-direction: column; align-items: center; width: 100%; min-width: 0; overflow: hidden; }
  .chart-box h4 { margin-bottom: 10px; color: var(--text-muted); text-align: center; font-size: 0.9rem; }
  .chart-container { position: relative; width: 100%; height: 180px; display: flex; justify-content: center; align-items: center; }
  .pie-chart-box { grid-column: 1 / -1; }

  .panel-section { display: none; flex: 1; }
  .panel-section.active { display: block; animation: fadeIn 0.3s; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
  .data-box { background: var(--card-bg); border-radius: 8px; border: 1px solid var(--border-color); overflow: hidden; margin-bottom: 15px; padding: 15px; }
  
  .form-group { display: flex; flex-direction: column; gap: 4px; margin-bottom: 12px;}
  .form-group label { font-size: 0.9rem; font-weight: 600; color: var(--text-muted); }
  .form-group input, .form-group textarea, .form-group select { padding: 10px; background: var(--card-light); border: 1px solid var(--border-color); border-radius: 6px; color: #fff; font-family: inherit; font-size: 0.95rem; width: 100%;}

  .table-responsive { width: 100%; overflow-x: auto; background: var(--card-bg); border-radius: 8px; }
  table { width: 100%; border-collapse: collapse; text-align: left; }
  th { background: var(--card-light); color: var(--text-muted); font-size: 0.85rem; padding: 12px 10px; white-space: nowrap; }
  td { padding: 12px 10px; border-bottom: 1px solid var(--border-color); font-size: 0.9rem; vertical-align: middle; }
  
  .btn { padding: 8px 15px; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; font-family: inherit; font-size: 0.95rem; display: inline-flex; align-items: center; justify-content: center; gap: 6px; color: #fff; transition: 0.2s; }
  .btn:hover { opacity: 0.8; }
  .btn-primary { background: var(--primary); }
  .btn-success { background: var(--success); }
  .btn-danger { background: var(--danger); }
  .btn-warning { background: var(--warning); }
  
  .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700; display: inline-block; font-family: sans-serif;}
  .bg-p { background: rgba(217,119,6,0.15); color: #fbbf24; }
  .bg-a { background: rgba(37,99,235,0.15); color: #60a5fa; }
  .bg-d { background: rgba(22,163,74,0.15); color: #4ade80; }
  .bg-c { background: rgba(220,38,38,0.15); color: #f87171; }

  .notice-banner { background: #311c11; border: 1px solid #7c2d12; color: #fdba74; padding: 10px; border-radius: 6px; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; overflow: hidden; }
  .notice-banner span { font-weight: bold; background: var(--accent); color:#fff; padding: 2px 6px; border-radius: 4px; font-size: 0.8rem; white-space: nowrap;}
  .notice-scroll-container { flex: 1; overflow: hidden; position: relative; height: 20px; display: flex; align-items: center; }
  .notice-scroll-text { display: inline-block; white-space: nowrap; animation: scrollLeft 120s linear infinite; font-size: 0.95rem; padding-left: 100%;}
  @keyframes scrollLeft { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }

  .service-card { background: var(--card-light); border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; display: flex; flex-direction: column; justify-content: space-between; gap: 10px;}
  .service-card h4 { color: var(--info); font-size: 1.1rem; }
  .service-card .price { font-weight: bold; font-family: sans-serif; font-size: 1.2rem; color: #fff; }
  .services-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; }

  .footer { text-align: center; padding: 15px; margin-top: auto; color: var(--text-muted); font-size: 0.9rem; border-top: 1px solid var(--border-color); }

  #authScreen { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #0f172a; width:100vw; position:fixed; z-index:9999; top:0; left:0;}
  .auth-box { background: var(--card-bg); border-radius: 12px; padding: 25px; width: 90%; max-width: 400px; border: 1px solid var(--border-color); max-height: 90vh; overflow-y: auto;}
  
  .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); display: none; align-items: center; justify-content: center; z-index: 999; }
  .modal-overlay.open { display: flex; }
  .modal-box { background: var(--card-bg); border: 1px solid var(--border-color); width: 100%; max-width: 500px; border-radius: 8px; padding: 20px; max-height: 90vh; overflow-y: auto;}

  @media(min-width: 769px) { .sidebar { transform: translateX(0) !important; } .main-content { margin-left: 240px; } }
  @media(max-width: 768px) { 
    .sidebar { transform: translateX(-100%); } .sidebar.open { transform: translateX(0); } .menu-toggle { display: block; } .main-content { margin-left: 0; } 
    .stats-grid { grid-template-columns: repeat(3, 1fr); gap: 6px; }
    .stat-card { padding: 8px 4px; text-align: center; gap: 5px; flex-direction: column;}
    .stat-value { font-size: 1rem; }
    .stat-label { font-size: 0.65rem; line-height: 1.1; }
    .charts-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .chart-box { padding: 10px; min-width: 0; }
    .chart-box h4 { font-size: 0.75rem; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .chart-container { height: 130px; }
  }
</style>
</head>
<body>

<div id="authScreen">
  <div class="auth-box" id="loginBox">
    <h2 style="color:var(--accent); text-align:center; margin-bottom:15px;"><i class="fa-solid fa-user"></i> User Login</h2>
    <div class="form-group"><label>Email</label><input type="email" id="loginEmail"></div>
    <div class="form-group" style="margin-bottom:15px"><label>Password</label><input type="password" id="loginPass"></div>
    <button class="btn btn-primary" style="width:100%;" onclick="userLogin()">Login</button>
    <p style="text-align:center; margin-top:15px; font-size:0.9rem; color:var(--text-muted);">Don't have an account? <span style="color:var(--info); cursor:pointer;" onclick="toggleAuthMode()">Sign Up</span></p>
  </div>

  <div class="auth-box" id="signupBox" style="display:none;">
    <h2 style="color:var(--accent); text-align:center; margin-bottom:15px;"><i class="fa-solid fa-user-plus"></i> Create Account</h2>
    <div class="form-group"><label>Profile Photo</label><input type="file" id="regPhoto" accept="image/*"></div>
    <div class="form-group"><label>Full Name</label><input type="text" id="regName"></div>
    <div class="form-group"><label>Email</label><input type="email" id="regEmail"></div>
    <div class="form-group"><label>Mobile Number</label><input type="text" id="regMobile" placeholder="01XXXXXXXXX"></div>
    <div class="form-group"><label>WhatsApp Number</label><input type="text" id="regWhatsApp" placeholder="01XXXXXXXXX"></div>
    <div class="form-group" style="margin-bottom:15px"><label>Password</label><input type="password" id="regPass"></div>
    <input type="hidden" id="regRole" value="user">
    
    <button class="btn btn-success" style="width:100%;" onclick="userSignUp(event)">Register</button>
    <p style="text-align:center; margin-top:15px; font-size:0.9rem; color:var(--text-muted);">Already have an account? <span style="color:var(--info); cursor:pointer;" onclick="toggleAuthMode()">Login</span></p>
  </div>
</div>

<div class="modal-overlay" id="orderModal">
  <div class="modal-box">
    <h3 id="modalServiceName" style="color:var(--info); margin-bottom:10px;">Service Name</h3>
    <p style="color:var(--warning); font-weight:bold; margin-bottom:15px;">Price: ৳<span id="modalServicePrice">0</span></p>
    
    <input type="hidden" id="orderServiceId">
    <input type="hidden" id="orderServicePrice">
    <input type="hidden" id="orderServiceName">
    
    <div id="dynamicFormFields"></div>
    
    <div class="form-group" id="fileUploadGroup" style="display:none; margin-top:10px;">
      <label id="fileUploadInstruction" style="color:var(--accent);"></label>
      <input type="file" id="orderFile">
      <small id="fileMandatoryAlert" style="color:var(--danger); display:none;">* File upload is mandatory for this service.</small>
    </div>

    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:20px;">
      <button class="btn btn-danger" onclick="closeOrderModal()">Cancel</button>
      <button class="btn btn-success" id="confirmOrderBtn" onclick="submitOrder()">Confirm Order</button>
    </div>
  </div>
</div>

<div class="modal-overlay" id="ticketModal">
  <div class="modal-box">
    <h3><i class="fa-solid fa-headset"></i> Open Support Ticket</h3>
    <div class="form-group"><label>Subject</label><input type="text" id="ticSubject" placeholder="Brief issue title..."></div>
    <div class="form-group"><label>Message</label><textarea id="ticMessage" rows="4" placeholder="Describe your problem..."></textarea></div>
    <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:15px;">
      <button class="btn btn-danger" onclick="closeTicketModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitTicket()">Submit</button>
    </div>
  </div>
</div>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
<div class="sidebar" id="sidebar">
  <div class="brand"><i class="fa-solid fa-bolt"></i> <span>E Online Service BD</span></div>

  <ul class="menu-list">
    <li class="menu-item active" onclick="switchTab('dashboard')"><i class="fa-solid fa-house"></i> Dashboard</li>
    <li class="menu-item" onclick="switchTab('profile')"><i class="fa-solid fa-user"></i> Profile</li>
    <li class="menu-item" onclick="switchTab('services')"><i class="fa-solid fa-briefcase"></i> Order Service</li>
    <li class="menu-item" onclick="switchTab('my-orders')"><i class="fa-solid fa-list-check"></i> My Orders</li>
    <li class="menu-item" onclick="switchTab('recharge')"><i class="fa-solid fa-wallet"></i> Add Balance</li>
    <li class="menu-item" onclick="switchTab('support')"><i class="fa-solid fa-headset"></i> Support</li>
  </ul>
</div>

<div class="main-content">
  
  <div class="top-bar">
    <div class="header-left">
      <button class="menu-toggle" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></button>
      <div class="page-title" id="pageTitle">DASHBOARD</div>
    </div>
    <div style="display:flex; align-items:center; gap:15px;">
       
       <div class="notification-wrapper" style="position:relative; display:inline-block; cursor:pointer;">
         <button class="notification-icon" onclick="toggleNotificationDropdown(event)" style="background:none; border:none; color:var(--text-main); font-size:1.4rem; cursor:pointer; position:relative;">
            <i class="fa-solid fa-bell"></i>
            <span id="notifBadge" style="display:none; position:absolute; top:-4px; right:-6px; background:var(--danger); color:#fff; font-size:0.65rem; font-weight:bold; padding:2px 5px; border-radius:50%;">0</span>
         </button>
         
         <div id="notification-dropdown" style="display:none; position:absolute; right:0; top:45px; width:300px; background:var(--card-bg); border:1px solid var(--border-color); border-radius:8px; box-shadow:0 8px 16px rgba(0,0,0,0.5); z-index:9999; overflow:hidden;">
            <div style="padding:12px 15px; background:var(--card-light); border-bottom:1px solid var(--border-color); display:flex; justify-content:space-between; align-items:center; font-weight:bold; font-size:0.9rem; color:var(--text-main);">
                <span>Notifications</span>
                <button onclick="markAllRead(event)" style="background:none; border:none; color:var(--info); font-size:0.8rem; cursor:pointer;">Mark all read</button>
            </div>
            <div id="notifList" style="max-height:350px; overflow-y:auto;">
            </div>
         </div>
      </div>

      <span class="user-bal-badge"><i class="fa-solid fa-bangladeshi-taka-sign"></i> <span id="topBalance">0</span></span>
    </div>
  </div>

  <div class="notice-banner">
    <span>NOTICE</span>
    <div class="notice-scroll-container">
       <div id="liveNoticeView" class="notice-scroll-text">Loading...</div>
    </div>
  </div>

  <div id="tab-dashboard" class="panel-section active">
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-info"><span class="stat-value">৳<span id="stat-bal">0</span></span><span class="stat-label">Current Balance</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" style="color:var(--danger);">৳<span id="stat-exp">0</span></span><span class="stat-label">Expense Balance</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="stat-tot-ord">0</span><span class="stat-label">Total Orders</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="stat-pen-ord" style="color:var(--warning);">0</span><span class="stat-label">Pending Orders</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="stat-com-ord" style="color:var(--success);">0</span><span class="stat-label">Completed Orders</span></div></div>
      <div class="stat-card"><div class="stat-info"><span class="stat-value" id="stat-can-ord" style="color:#ef4444;">0</span><span class="stat-label">Cancel Orders</span></div></div>
    </div>

    <div class="charts-grid">
      <div class="chart-box">
         <h4>Orders Status</h4>
         <div class="chart-container"><canvas id="userColChart"></canvas></div>
      </div>
      <div class="chart-box">
         <h4>Expense Graph</h4>
         <div class="chart-container"><canvas id="userLineChart"></canvas></div>
      </div>
      <div class="chart-box pie-chart-box">
         <h4>Ratio (Pie)</h4>
         <div class="chart-container"><canvas id="userPieChart"></canvas></div>
      </div>
    </div>
  </div>

  <div id="tab-profile" class="panel-section">
      <div class="data-box" style="max-width: 600px; margin: 0 auto; text-align: center; padding: 30px 20px;">
          <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Profile Photo" id="tabProfPhoto" style="width: 110px; height: 110px; border-radius: 50%; object-fit: cover; border: 3px solid var(--accent); margin-bottom: 15px; background: var(--card-light);">
          <h2 id="tabProfName" style="color: var(--text-main); margin-bottom: 5px;">Loading...</h2>
          <p id="tabProfEmail" style="color: var(--text-muted); margin-bottom: 5px; font-size: 0.95rem;">loading@email.com</p>
          
          <div style="margin-bottom: 20px;">
              <span class="badge bg-a" id="tabProfRole" style="font-size: 0.85rem; padding: 6px 12px; border-radius: 20px;"><i class="fa-solid fa-user-shield"></i> User</span>
          </div>
          
          <div style="text-align: left; background: var(--card-light); padding: 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid var(--border-color);">
            <div style="margin-bottom: 15px;">
                <small style="color: var(--accent); font-weight: bold;">User ID (UID)</small>
                <div id="tabProfUID" style="font-size: 1.05rem; margin-top: 5px; color: var(--text-main); font-family: monospace;">Loading...</div>
            </div>
            <hr style="border: 1px solid var(--border-color); margin: 15px 0;">
            <div style="margin-bottom: 15px;">
                <small style="color: var(--accent); font-weight: bold;">Mobile Number</small>
                <div id="tabProfMobile" style="font-size: 1.05rem; margin-top: 5px; color: var(--text-main);">+8801XXXXXXXXX</div>
            </div>
            <hr style="border: 1px solid var(--border-color); margin: 15px 0;">
            <div style="margin-bottom: 15px;">
                <small style="color: var(--accent); font-weight: bold;">WhatsApp Number</small>
                <div id="tabProfWhatsApp" style="font-size: 1.05rem; margin-top: 5px; color: var(--text-main);">+8801XXXXXXXXX</div>
            </div>
            <hr style="border: 1px solid var(--border-color); margin: 15px 0;">
            <div>
                <small style="color: var(--accent); font-weight: bold;">Account Status</small>
                <div style="margin-top: 5px;"><span class="badge bg-d" id="tabProfStatus">Active</span></div>
            </div>
          </div>

          <button class="btn btn-danger" onclick="userLogout()" style="width: 100%; padding: 12px; font-size: 1.05rem;"><i class="fa-solid fa-right-from-bracket"></i> Logout Account</button>
      </div>
  </div>

  <div id="tab-services" class="panel-section">
    <div class="data-box" style="background:transparent; border:none; padding:0;">
      <h3 style="margin-bottom:15px;"><i class="fa-solid fa-list"></i> Available Services</h3>
      <div class="form-group" style="max-width: 300px; margin-bottom:20px;">
         <select id="userCatFilter" onchange="renderServices()">
            <option value="All">All Categories</option>
         </select>
      </div>
      <div class="services-grid" id="servicesContainer">
         </div>
    </div>
  </div>

  <div id="tab-my-orders" class="panel-section">
    <div class="data-box">
      <h3><i class="fa-solid fa-clock-rotate-left"></i> My Order History</h3>
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Date</th>
              <th>Service Name</th>
              <th>Price</th>
              <th>Status</th>
              <th>Delivery Info / File</th>
            </tr>
          </thead>
          <tbody id="userOrdersTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="tab-recharge" class="panel-section">
    <div class="data-box">
      <h3 style="color:var(--success);"><i class="fa-solid fa-money-bill-transfer"></i> Add Balance</h3>
      <p style="color:var(--text-muted); margin-bottom:20px; line-height:1.6;">
      বিকাশ,নগদ,রকেট এর মাধ্যমে টাকা পাঠানোর আগে অবশ্যই দেখে নিবেন একাউন্ট নম্বর এবং একাউন্ট এর ধরণ।
      </p>
      
      <div style="display:flex; gap:15px; flex-wrap:wrap; margin-bottom:25px;" id="paymentMethodsView">
         </div>

      <div style="background:var(--card-light); padding:20px; border-radius:8px; border:1px solid var(--border-color); max-width:500px;">
         <h4 style="margin-bottom:15px;">Submit Recharge Request</h4>
         <div class="form-group"><label>Payment Method</label><select id="recMethod"><option value="bKash">bKash</option><option value="Nagad">Nagad</option><option value="Rocket">Rocket</option></select></div>
         <div class="form-group"><label>Transaction ID (TrxID)</label><input type="text" id="recTrxId" placeholder="e.g. 9BCA1234XYZ"></div>
         <div class="form-group"><label>Sent Amount (৳)</label><input type="number" id="recAmount" placeholder="0"></div>
         <button class="btn btn-success" style="width:100%; margin-top:10px;" onclick="submitRecharge()">Send Request</button>
      </div>
    </div>

    <div class="data-box">
      <h3><i class="fa-solid fa-list-ol"></i> Recharge History</h3>
      <div class="table-responsive">
        <table><thead><tr><th>Date</th><th>Method</th><th>TrxID</th><th>Amount</th><th>Status</th></tr></thead><tbody id="userRechargeTable"></tbody></table>
      </div>
    </div>
  </div>

  <div id="tab-support" class="panel-section">
    <div class="data-box">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
         <h3><i class="fa-solid fa-headset"></i> My Support Tickets</h3>
         <button class="btn btn-primary btn-sm" onclick="openTicketModal()"><i class="fa-solid fa-plus"></i> New Ticket</button>
      </div>
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Subject</th>
              <th>Your Message</th>
              <th>Admin Reply</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="userTicketsTable"></tbody>
        </table>
      </div>
    </div>
    
    <div class="data-box" style="text-align:center;">
       <h4 style="margin-bottom:10px;">Direct Contact</h4>
       <div style="display:flex; justify-content:center; gap:10px;">
          <a id="contact-wa" href="#" target="_blank" class="btn" style="background:#25D366;"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
          <a id="contact-tg" href="#" target="_blank" class="btn" style="background:#0088cc;"><i class="fa-brands fa-telegram"></i> Telegram</a>
       </div>
    </div>
  </div>

  <footer class="footer">
      Copyright @ 2026 | E Online Service BD
  </footer>
</div>

<script type="module">
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
  import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
  import { getFirestore, doc, setDoc, getDoc, collection, onSnapshot, query, where, orderBy, runTransaction, addDoc, updateDoc } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

  const firebaseConfig = {
    apiKey: "AIzaSyADPFsjyqo0zUXzXFzCQ40YbUQDKW5qd2o",
    authDomain: "e-online-service.firebaseapp.com",
    projectId: "e-online-service",
    storageBucket: "e-online-service.firebasestorage.app",
    messagingSenderId: "557870086410",
    appId: "1:557870086410:web:926155d23b0ff67fb222f3"
  };

  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);
  const db = getFirestore(app);

  let currentUser = null;
  let userData = { balance: 0 };
  let allServices = [];
  let userOrders = [];
  let serviceRequirementsCache = [];
  let isFileMandatoryCache = false;

  let userColChartInst = null;
  let userLineChartInst = null;
  let userPieChartInst = null;
  let userNotifsArray = [];
  
  window.isRegistering = false;

  function initUserNotifications() {
      const qNotif = query(collection(db, "notifications"), where("target", "==", "user"), where("userId", "==", currentUser.uid));
      onSnapshot(qNotif, (snap) => {
          userNotifsArray = []; let unread = 0;
          snap.forEach(d => { let n = {id: d.id, ...d.data()}; userNotifsArray.push(n); if(!n.isRead) unread++; });
          userNotifsArray.sort((a,b) => b.timestamp - a.timestamp);

          const badge = document.getElementById('notifBadge');
          if(unread > 0) { badge.textContent = unread; badge.style.display = 'block'; } else { badge.style.display = 'none'; }

          const list = document.getElementById('notifList'); list.innerHTML = '';
          if(userNotifsArray.length === 0) {
              list.innerHTML = '<div style="padding:20px; text-align:center; color:var(--text-muted); font-size:0.85rem;">No notifications yet.</div>';
          } else {
              userNotifsArray.forEach((n, index) => {
                  let time = formatToCustomDate(n.date) + ' ' + new Date(n.timestamp).toLocaleTimeString();
                  let bg = n.isRead ? 'transparent' : 'rgba(37,99,235,0.1)';
                  list.innerHTML += `<div onclick="readNotif('${n.id}')" style="padding:12px 15px; border-bottom:1px solid var(--border-color); font-size:0.85rem; color:var(--text-main); display:flex; gap:8px; cursor:pointer; background:${bg};">
                      <span style="color:var(--accent); font-weight:bold; font-size:0.9rem;">${index + 1}.</span>
                      <div style="flex:1; line-height:1.4;">
                          <div style="font-weight:bold;">${n.title}</div>
                          <div>${n.message}</div>
                          <span style="display:block; font-size:0.7rem; color:var(--info); margin-top:4px;">${time}</span>
                      </div>
                  </div>`;
              });
          }
      });
  }

  window.toggleNotificationDropdown = function(event) { 
      event.stopPropagation(); 
      const dropdown = document.getElementById('notification-dropdown');
      if(dropdown.style.display === 'none' || dropdown.style.display === '') {
          dropdown.style.display = 'block';
      } else {
          dropdown.style.display = 'none';
      }
  };
  window.readNotif = async function(id) { await updateDoc(doc(db, "notifications", id), { isRead: true }); document.getElementById('notification-dropdown').style.display = 'none'; };
  window.markAllRead = function(event) { event.stopPropagation(); userNotifsArray.forEach(async (n) => { if(!n.isRead) await updateDoc(doc(db, "notifications", n.id), { isRead: true }); }); };
  window.sendNotification = async function(target, userId, title, message) {
      try { await addDoc(collection(db, "notifications"), { target, userId, title, message, isRead: false, timestamp: Date.now(), date: new Date().toISOString() }); } catch(e) {}
  };
  
  window.addEventListener('click', function(event) { 
      const wrapper = document.querySelector('.notification-wrapper');
      const dropdown = document.getElementById('notification-dropdown');
      if (dropdown && dropdown.style.display === 'block' && (!wrapper || !wrapper.contains(event.target))) { 
          dropdown.style.display = 'none'; 
      }
  });

  window.toggleSidebar = function() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
  };

  window.switchTab = function(id) { 
      document.querySelectorAll('.panel-section').forEach(el => el.classList.remove('active')); 
      document.getElementById('tab-' + id).classList.add('active'); 
      document.getElementById('pageTitle').textContent = id.toUpperCase().replace('-', ' '); 
      document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
      event.currentTarget.classList.add('active');
      if(window.innerWidth <= 768) toggleSidebar();
  };

  window.toggleAuthMode = function() {
      const login = document.getElementById('loginBox');
      const signup = document.getElementById('signupBox');
      if(login.style.display === 'none') { login.style.display = 'block'; signup.style.display = 'none'; } 
      else { login.style.display = 'none'; signup.style.display = 'block'; }
  };

  window.userLogin = async function() {
      const email = document.getElementById('loginEmail').value;
      const pass = document.getElementById('loginPass').value;
      if(!email || !pass) return alert("Enter email and password!");
      try { await signInWithEmailAndPassword(auth, email, pass); } catch(e) { alert(e.message); }
  };

  window.userSignUp = async function(event) {
      const photoFile = document.getElementById('regPhoto').files[0];
      const name = document.getElementById('regName').value;
      const email = document.getElementById('regEmail').value;
      const mobile = document.getElementById('regMobile').value;
      const whatsapp = document.getElementById('regWhatsApp').value;
      const pass = document.getElementById('regPass').value;
      const role = document.getElementById('regRole').value;
      
      if(!name || !email || !mobile || !whatsapp || !pass) return alert("Fill all required fields!");

      const btn = event.target;
      const originalText = btn.textContent;
      btn.disabled = true;

      window.isRegistering = true;

      try {
          let photoUrlToSave = "";
          
          if (photoFile) {
              btn.textContent = 'Uploading Photo...';
              
              if(typeof window.wp_ajax !== 'undefined') {
                  let fd = new FormData(); 
                  fd.append('action', 'upload_delivery_file'); 
                  fd.append('file', photoFile); 
                  fd.append('security', window.wp_ajax.nonce);
                  
                  try { 
                      let res = await fetch(window.wp_ajax.ajax_url, { method: 'POST', body: fd }); 
                      let json = await res.json(); 
                      if(json.success) {
                          photoUrlToSave = json.data.url; 
                      } else {
                          console.error("Hosting rejected the upload.");
                      }
                  } catch(uploadErr) { 
                      console.error("Hosting Upload Error:", uploadErr); 
                  }
              } else {
                  console.warn("wp_ajax configuration is missing on the signup page. Saving account without photo URL.");
              }
          }

          btn.textContent = 'Creating Account...';
          console.log("Creating user in Firebase Auth...");
          const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
          const user = userCredential.user;

          console.log("Saving user data to Firestore...");
          
          await setDoc(doc(db, "users", user.uid), {
              photoUrl: photoUrlToSave,
              name: name,
              email: email,
              mobile: mobile,
              whatsapp: whatsapp,
              role: role || 'user',
              balance: 0,
              status: 'Pending',
              customId: '', 
              date: new Date().toISOString()
          });

          await setDoc(doc(db, "pending_users", user.uid), {
              uid: user.uid,
              name: name,
              email: email,
              mobile: mobile,
              whatsapp: whatsapp,
              status: 'Pending',
              date: new Date().toISOString()
          });

          console.log("User data successfully saved!");
          alert("আপনার রেজিস্ট্রেশন সফল হয়েছে! অ্যাডমিন অনুমোদনের জন্য অপেক্ষা করুন।");

          document.getElementById('regPhoto').value = '';
          document.getElementById('regName').value = '';
          document.getElementById('regEmail').value = '';
          document.getElementById('regMobile').value = '';
          document.getElementById('regWhatsApp').value = '';
          document.getElementById('regPass').value = '';
          
          window.isRegistering = false;
          await signOut(auth);
          toggleAuthMode(); 

      } catch(e) { 
          window.isRegistering = false;
          console.error("Error: ", e);
          alert(e.message); 
      } finally {
          btn.disabled = false;
          btn.textContent = originalText;
      }
  };

  window.userLogout = function() { signOut(auth); };

  onAuthStateChanged(auth, async (user) => {
    if (window.isRegistering) return; 

    if (user) {
      currentUser = user;
      
      try {
          const userRef = doc(db, "users", user.uid);
          const userSnap = await getDoc(userRef);

          if(userSnap.exists()) {
              const uData = userSnap.data();
              
              if(uData.status === 'Pending' || !uData.customId) {
                  alert("আপনার অ্যাকাউন্টটি এখনও অ্যাডমিন দ্বারা অনুমোদিত হয়নি। অনুগ্রহ করে অনুমোদনের জন্য অপেক্ষা করুন।");
                  await signOut(auth);
                  currentUser = null;
                  document.getElementById('authScreen').style.display = 'flex';
              } else if (uData.status === 'suspended') {
                  alert("আপনার অ্যাকাউন্টটি সাসপেন্ড করা হয়েছে!");
                  await signOut(auth);
                  currentUser = null;
                  document.getElementById('authScreen').style.display = 'flex';
              } else {
                  document.getElementById('authScreen').style.display = 'none';
                  loadUserEcosystem();
              }
          } else {
              alert("অ্যাকাউন্ট ডেটা পাওয়া যায়নি! অ্যাডমিন অনুমোদনের জন্য অপেক্ষা করুন।");
              await signOut(auth);
              currentUser = null;
              document.getElementById('authScreen').style.display = 'flex';
          }
      } catch(e) {
          console.error("Error fetching user data: ", e);
          alert("ডাটাবেজ থেকে তথ্য আনা সম্ভব হয়নি! " + e.message);
          await signOut(auth);
          currentUser = null;
          document.getElementById('authScreen').style.display = 'flex';
      }
    } else {
      currentUser = null;
      document.getElementById('authScreen').style.display = 'flex';
    }
  });

  function formatToCustomDate(dateStr) {
      if(!dateStr) return 'N/A';
      const d = new Date(dateStr);
      if(isNaN(d)) return dateStr.split(' ')[0];
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      return `${String(d.getDate()).padStart(2, '0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
  }

  function loadUserEcosystem() {
      initUserNotifications(); 
      
      onSnapshot(doc(db, "users", currentUser.uid), (docSnap) => {
          if(docSnap.exists()) {
              userData = docSnap.data();
              document.getElementById('topBalance').textContent = userData.balance || 0;
              document.getElementById('stat-bal').textContent = userData.balance || 0;
              
              document.getElementById('tabProfName').textContent = userData.name || 'Anonymous User';
              document.getElementById('tabProfUID').textContent = userData.customId || currentUser.uid;
              document.getElementById('tabProfEmail').textContent = userData.email || currentUser.email;
              document.getElementById('tabProfMobile').textContent = userData.mobile || 'No Mobile Available';
              document.getElementById('tabProfWhatsApp').textContent = userData.whatsapp || 'No WhatsApp Provided';
              document.getElementById('tabProfRole').innerHTML = `<i class="fa-solid fa-user-shield"></i> ${(userData.role || 'user').toUpperCase()}`;
              document.getElementById('tabProfStatus').textContent = (userData.status || 'Active').toUpperCase();
              
              if(userData.photoUrl && userData.photoUrl !== "") {
                  document.getElementById('tabProfPhoto').src = userData.photoUrl;
              } else {
                  document.getElementById('tabProfPhoto').src = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
              }
          }
      });

      onSnapshot(doc(db, "settings", "global"), (snap) => {
          if(snap.exists() && snap.data().notice) {
              const text = snap.data().notice;
              document.getElementById('liveNoticeView').innerHTML = `${text} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ${text} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ${text}`;
          }
      });
      
      onSnapshot(doc(db, "settings", "contact_config"), (snap) => {
          if(snap.exists()) {
             const d = snap.data();
             if(d.whatsapp) document.getElementById('contact-wa').href = d.whatsapp;
             if(d.telegram) document.getElementById('contact-tg').href = d.telegram;
          }
      });

      onSnapshot(doc(db, "settings", "payment_config"), (snap) => {
          const view = document.getElementById('paymentMethodsView'); view.innerHTML = '';
          if(snap.exists()) {
              const data = snap.data();
              ['bkash', 'nagad', 'rocket'].forEach(m => {
                 if(data[m] && data[m].status && data[m].number) {
                    view.innerHTML += `<div style="background:var(--bg-dark); border:1px dashed var(--accent); padding:10px 15px; border-radius:6px; flex:1; min-width:150px; text-align:center;">
                       <strong style="text-transform:capitalize; color:var(--info);">
  ${m} (${data[m].type} - ${data[m].type.toLowerCase() === 'personal' ? 'Send Money' : data[m].type.toLowerCase() === 'merchant' ? 'Payment' : 'Cash Out'})
</strong><br>
                       <span style="font-size:1.1rem; font-weight:bold; letter-spacing:1px; font-family:sans-serif;">${data[m].number}</span>
                    </div>`;
                 }
              });
          }
      });

      onSnapshot(collection(db, "categories"), (snap) => {
          const catFilter = document.getElementById('userCatFilter');
          catFilter.innerHTML = '<option value="All">All Categories</option>';
          snap.forEach(d => { catFilter.innerHTML += `<option value="${d.data().name}">${d.data().name}</option>`; });
      });

      onSnapshot(collection(db, "services"), (snap) => {
          allServices = [];
          snap.forEach(d => { if(d.data().enabled) allServices.push({ id: d.id, ...d.data() }); });
          renderServices();
      });

      const qOrders = query(collection(db, "orders"), where("userId", "==", currentUser.uid));
      onSnapshot(qOrders, (snap) => {
          userOrders = []; 
          let pen = 0, com = 0, can = 0, exp = 0;
          let dateExp = {};

          snap.forEach(d => { 
              let o = { id: d.id, ...d.data() }; 
              userOrders.push(o); 
              
              if(o.status === 'Pending') { pen++; exp += Number(o.price); }
              if(o.status === 'Success') { com++; exp += Number(o.price); }
              if(o.status === 'Cancel') { can++; }

              if(o.status !== 'Cancel') {
                  let dKey = o.date ? o.date.split(' ')[0] : 'N/A';
                  dateExp[dKey] = (dateExp[dKey] || 0) + Number(o.price);
              }
          });
          
          document.getElementById('stat-tot-ord').textContent = userOrders.length;
          document.getElementById('stat-pen-ord').textContent = pen;
          document.getElementById('stat-com-ord').textContent = com;
          document.getElementById('stat-can-ord').textContent = can;
          document.getElementById('stat-exp').textContent = exp;
          
          const t = document.getElementById('userOrdersTable'); t.innerHTML = '';
          userOrders.sort((a,b) => new Date(b.date) - new Date(a.date)).forEach(o => {
             let deliveryHtml = '-';
             if(o.status === 'Success') {
                 let note = o.deliveryNote ? `Note: ${o.deliveryNote}` : '';
                 let fLink = o.deliveryFile ? `<br><a href="${o.deliveryFile}" download target="_blank" class="btn btn-success" style="padding:4px 8px; font-size:12px; margin-top:5px;"><i class="fa-solid fa-download"></i> Download</a>` : '';
                 deliveryHtml = `<div style="font-size:13px;">${note} ${fLink}</div>`;
             } else if (o.status === 'Cancel') {
                 deliveryHtml = `<span style="color:var(--danger); font-size:12px;">Reason: ${o.cancelReason || 'Not specified'}</span>`;
             }
             
             t.innerHTML += `<tr>
                <td><b>${o.id}</b></td>
                <td>${formatToCustomDate(o.date)}</td>
                <td>${o.workName}</td>
                <td>৳${o.price}</td>
                <td><span class="badge ${o.status==='Pending'?'bg-p':(o.status==='Success'?'bg-d':'bg-c')}">${o.status}</span></td>
                <td>${deliveryHtml}</td>
             </tr>`;
          });

          updateUserCharts(pen, com, can, dateExp);
      });

      const qDep = query(collection(db, "deposits"), where("userId", "==", currentUser.uid));
      onSnapshot(qDep, (snap) => {
         const t = document.getElementById('userRechargeTable'); t.innerHTML = '';
         let arr = []; snap.forEach(d => arr.push(d.data()));
         arr.sort((a,b) => new Date(b.date) - new Date(a.date)).forEach(r => {
             t.innerHTML += `<tr>
                <td>${formatToCustomDate(r.date)}</td>
                <td>${r.method}</td>
                <td>${r.trxId}</td>
                <td>৳${r.amount}</td>
                <td><span class="badge ${r.status==='Pending'?'bg-p':(r.status==='Approved'?'bg-d':'bg-c')}">${r.status}</span></td>
             </tr>`;
         });
      });

      const qTic = query(collection(db, "tickets"), where("userId", "==", currentUser.uid));
      onSnapshot(qTic, (snap) => {
         const t = document.getElementById('userTicketsTable'); t.innerHTML = '';
         let arr = []; snap.forEach(d => arr.push(d.data()));
         arr.sort((a,b) => new Date(b.date) - new Date(a.date)).forEach(tic => {
             t.innerHTML += `<tr>
                <td>${formatToCustomDate(tic.date)}</td>
                <td>${tic.subject}</td>
                <td>${tic.message}</td>
                <td><span style="color:var(--info); font-size:13px;">${tic.adminCloseNote || '-'}</span></td>
                <td><span class="badge ${tic.status==='Open'?'bg-p':'bg-d'}">${tic.status}</span></td>
             </tr>`;
         });
      });
  }

  function updateUserCharts(pen, com, can, dateExp) {
      Chart.defaults.color = '#94a3b8';
      Chart.defaults.font.family = "'Times New Roman', serif";

      const ctxCol = document.getElementById('userColChart');
      if(ctxCol) {
          if(userColChartInst) userColChartInst.destroy();
          userColChartInst = new Chart(ctxCol, {
              type: 'bar',
              data: { labels: ['Pending', 'Completed', 'Canceled'], datasets: [{ data: [pen, com, can], backgroundColor: ['#d97706', '#16a34a', '#dc2626'], borderRadius: 4 }] },
              options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
          });
      }

      const ctxLine = document.getElementById('userLineChart');
      if(ctxLine) {
          if(userLineChartInst) userLineChartInst.destroy();
          let sortedDates = Object.keys(dateExp).sort((a,b) => new Date(a) - new Date(b));
          let expData = sortedDates.map(d => dateExp[d]);
          userLineChartInst = new Chart(ctxLine, {
              type: 'line',
              data: { labels: sortedDates.length ? sortedDates : ['N/A'], datasets: [{ label: 'Expense (৳)', data: expData.length ? expData : [0], borderColor: '#06b6d4', backgroundColor: 'rgba(6, 182, 212, 0.1)', tension: 0.3, fill: true }] },
              options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
          });
      }

      const ctxPie = document.getElementById('userPieChart');
      if(ctxPie) {
          if(userPieChartInst) userPieChartInst.destroy();
          userPieChartInst = new Chart(ctxPie, {
              type: 'doughnut', 
              data: { labels: ['Pending', 'Completed', 'Canceled'], datasets: [{ data: [pen, com, can], backgroundColor: ['#d97706', '#16a34a', '#dc2626'], borderWidth: 0 }] },
              options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
          });
      }
  }

  window.renderServices = function() {
      const filter = document.getElementById('userCatFilter').value;
      const cont = document.getElementById('servicesContainer'); cont.innerHTML = '';
      allServices.filter(s => filter === 'All' || s.category === filter).forEach(s => {
          let reqsStr = s.requirements ? encodeURIComponent(JSON.stringify(s.requirements)) : '[]';
          let encIns = s.fileInstruction ? encodeURIComponent(s.fileInstruction) : '';
          cont.innerHTML += `<div class="service-card">
              <div>
                 <h4>${s.name}</h4>
                 <div style="font-size:0.8rem; color:var(--text-muted); margin-top:5px;">Category: ${s.category}</div>
              </div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
                 <span class="price">৳${s.price}</span>
                 <button class="btn btn-primary" onclick="initiateOrder('${s.id}', '${encodeURIComponent(s.name)}', ${s.price}, '${reqsStr}', ${s.fileNeeded}, '${encIns}')">Order Now</button>
              </div>
          </div>`;
      });
  }

  window.initiateOrder = function(id, nameEnc, price, reqsStrEnc, fileNeeded, fileInsEnc) {
      if(userData.balance < price) return alert(`Insufficient Balance! You need ৳${price} but have ৳${userData.balance}`);
      
      const name = decodeURIComponent(nameEnc);
      const reqs = JSON.parse(decodeURIComponent(reqsStrEnc));
      serviceRequirementsCache = reqs;
      isFileMandatoryCache = fileNeeded;

      document.getElementById('modalServiceName').textContent = name;
      document.getElementById('modalServicePrice').textContent = price;
      document.getElementById('orderServiceId').value = id;
      document.getElementById('orderServiceName').value = name;
      document.getElementById('orderServicePrice').value = price;

      const dynamicForm = document.getElementById('dynamicFormFields'); dynamicForm.innerHTML = '';
      reqs.forEach(r => {
          if(r.trim() !== '') {
              dynamicForm.innerHTML += `<div class="form-group"><label>${r}</label><input type="text" id="req_f_${r.replace(/\s+/g, '')}" required></div>`;
          }
      });

      const fileGroup = document.getElementById('fileUploadGroup');
      if(fileNeeded || decodeURIComponent(fileInsEnc) !== '') {
          fileGroup.style.display = 'block';
          document.getElementById('fileUploadInstruction').textContent = decodeURIComponent(fileInsEnc) || 'Upload Required File';
          document.getElementById('fileMandatoryAlert').style.display = fileNeeded ? 'block' : 'none';
      } else {
          fileGroup.style.display = 'none';
      }

      document.getElementById('orderModal').classList.add('open');
  }
  
  window.closeOrderModal = function() { document.getElementById('orderModal').classList.remove('open'); }

  window.submitOrder = async function() {
      const price = Number(document.getElementById('orderServicePrice').value);
      if(userData.balance < price) return alert("Insufficient balance! Please recharge.");

      const btn = document.getElementById('confirmOrderBtn'); btn.disabled = true; btn.textContent = 'Processing...';

      let customData = {}; let isFormValid = true;
      serviceRequirementsCache.forEach(r => {
          if(r.trim() !== '') {
              let val = document.getElementById(`req_f_${r.replace(/\s+/g, '')}`).value;
              if(!val) isFormValid = false;
              customData[r] = val;
          }
      });
      if(!isFormValid) { alert("Please fill all requirement fields."); btn.disabled=false; btn.textContent='Confirm Order'; return; }

      const fileInput = document.getElementById('orderFile');
      if(isFileMandatoryCache && fileInput.files.length === 0) { alert("File upload is mandatory for this service!"); btn.disabled=false; btn.textContent='Confirm Order'; return; }

      let fileUrl = '';
      if(fileInput.files.length > 0) {
          if(typeof window.wp_ajax !== 'undefined') {
              let fd = new FormData(); fd.append('action', 'upload_delivery_file'); fd.append('file', fileInput.files[0]); fd.append('security', window.wp_ajax.nonce);
              try { let res = await fetch(window.wp_ajax.ajax_url, { method: 'POST', body: fd }); let json = await res.json(); if(json.success) fileUrl = json.data.url; } catch(e) { console.log(e); }
          } else {
             fileUrl = "user_uploaded_file_" + Date.now(); 
          }
      }

      try {
          await runTransaction(db, async (trans) => {
              const uRef = doc(db, "users", currentUser.uid);
              const uDoc = await trans.get(uRef);
              if (uDoc.data().balance < price) throw "Balance too low.";
              
              trans.update(uRef, { balance: uDoc.data().balance - price });
              
              const orderIdGen = "ORD" + Math.floor(10000 + Math.random() * 90000);
              const newOrderRef = doc(db, "orders", orderIdGen);
              trans.set(newOrderRef, {
                  userId: currentUser.uid,
                  userEmail: currentUser.email,
                  workName: document.getElementById('orderServiceName').value,
                  price: price,
                  status: 'Pending',
                  date: new Date().toISOString().split('T')[0],
                  customData: customData,
                  fileUrl: fileUrl
              });
          });
          
          sendNotification('admin', null, 'New Order Placed', 'User ' + currentUser.email + ' placed a new order.');
          
          alert("Order placed successfully!"); closeOrderModal();
      } catch(err) { alert("Order failed: " + err); }
      finally { btn.disabled=false; btn.textContent='Confirm Order'; }
  }

  window.submitRecharge = async function() {
      const method = document.getElementById('recMethod').value;
      const trxId = document.getElementById('recTrxId').value.trim();
      const amount = Number(document.getElementById('recAmount').value);

      if(!trxId || amount <= 0) return alert("Enter valid TrxID and Amount!");

      await setDoc(doc(db, "deposits", "DEP" + Date.now()), {
          userId: currentUser.uid, userEmail: currentUser.email,
          method: method, trxId: trxId, amount: amount,
          status: 'Pending', date: new Date().toISOString().split('T')[0]
      });
      
      sendNotification('admin', null, 'New Recharge Request', 'Recharge request for ৳' + amount + ' by ' + currentUser.email);
      
      alert("Recharge request sent! Waiting for admin approval.");
      document.getElementById('recTrxId').value = ''; document.getElementById('recAmount').value = '';
  }

  window.openTicketModal = function() { document.getElementById('ticketModal').classList.add('open'); }
  window.closeTicketModal = function() { document.getElementById('ticketModal').classList.remove('open'); }
  window.submitTicket = async function() {
      const sub = document.getElementById('ticSubject').value.trim();
      const msg = document.getElementById('ticMessage').value.trim();
      if(!sub || !msg) return alert("Fill subject and message!");

      await setDoc(doc(db, "tickets", "TIC" + Date.now()), {
          userId: currentUser.uid, userEmail: currentUser.email,
          subject: sub, message: msg, status: 'Open', adminCloseNote: '',
          date: new Date().toISOString().split('T')[0]
      });
      
      sendNotification('admin', null, 'New Support Ticket', 'User ' + currentUser.email + ' opened a new ticket.');
      
      alert("Ticket submitted successfully!");
      document.getElementById('ticSubject').value = ''; document.getElementById('ticMessage').value = '';
      closeTicketModal();
  }
</script>

<?php wp_footer(); ?>
</body>
</html>
