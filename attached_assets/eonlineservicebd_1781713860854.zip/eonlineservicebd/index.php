<?php get_header(); ?>

<main id="dashboard-container">
    <?php
    if ( is_user_logged_in() ) {
        // WordPress user logged in hole dashboard load hobe
        echo '<div id="wp-dashboard-app">';
        // Ekhane apnar HTML content load hobe
        include(get_template_directory() . '/dashboard-content.php'); 
        echo '</div>';
    } else {
        // Logged in na hole login form
        echo '<div class="login-msg">Doya kore prothomoto login korun.</div>';
        echo do_shortcode('[wp_login_form]');
    }
    ?>
</main>

<?php get_footer(); ?>
